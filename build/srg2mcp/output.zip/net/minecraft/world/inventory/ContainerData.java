package net.minecraft.world.inventory;

public interface ContainerData {
   int get(int p_39284_);

   void set(int p_39285_, int p_39286_);

   int getCount();
}