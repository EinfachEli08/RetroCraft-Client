package net.minecraft.util;

import com.mojang.logging.LogUtils;
import java.security.PrivateKey;
import java.security.Signature;
import org.slf4j.Logger;

public interface Signer {
   Logger f_216381_ = LogUtils.getLogger();

   byte[] m_216395_(SignatureUpdater p_216396_);

   default byte[] m_216390_(byte[] p_216391_) {
      return this.m_216395_((p_216394_) -> {
         p_216394_.m_216346_(p_216391_);
      });
   }

   static Signer m_216387_(PrivateKey p_216388_, String p_216389_) {
      return (p_216386_) -> {
         try {
            Signature signature = Signature.getInstance(p_216389_);
            signature.initSign(p_216388_);
            p_216386_.m_216344_(signature::update);
            return signature.sign();
         } catch (Exception exception) {
            throw new IllegalStateException("Failed to sign message", exception);
         }
      };
   }
}