package net.minecraft.world.entity.npc;

public interface Npc {
}