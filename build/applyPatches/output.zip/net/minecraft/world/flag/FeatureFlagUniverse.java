package net.minecraft.world.flag;

public class FeatureFlagUniverse {
   private final String f_243740_;

   public FeatureFlagUniverse(String p_249484_) {
      this.f_243740_ = p_249484_;
   }

   public String toString() {
      return this.f_243740_;
   }
}