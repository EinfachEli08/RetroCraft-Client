package net.minecraft.world.level.levelgen;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Charsets;
import com.google.common.hash.HashFunction;
import com.google.common.hash.Hashing;
import com.google.common.primitives.Longs;
import java.util.concurrent.atomic.AtomicLong;

public final class RandomSupport {
   public static final long f_189323_ = -7046029254386353131L;
   public static final long f_189324_ = 7640891576956012809L;
   private static final HashFunction f_287788_ = Hashing.md5();
   private static final AtomicLong f_189325_ = new AtomicLong(8682522807148012L);

   @VisibleForTesting
   public static long m_189329_(long p_189330_) {
      p_189330_ = (p_189330_ ^ p_189330_ >>> 30) * -4658895280553007687L;
      p_189330_ = (p_189330_ ^ p_189330_ >>> 27) * -7723592293110705685L;
      return p_189330_ ^ p_189330_ >>> 31;
   }

   public static RandomSupport.Seed128bit m_289611_(long p_289660_) {
      long i = p_289660_ ^ 7640891576956012809L;
      long j = i + -7046029254386353131L;
      return new RandomSupport.Seed128bit(i, j);
   }

   public static RandomSupport.Seed128bit m_189331_(long p_189332_) {
      return m_289611_(p_189332_).m_289608_();
   }

   public static RandomSupport.Seed128bit m_288212_(String p_288994_) {
      byte[] abyte = f_287788_.hashString(p_288994_, Charsets.UTF_8).asBytes();
      long i = Longs.fromBytes(abyte[0], abyte[1], abyte[2], abyte[3], abyte[4], abyte[5], abyte[6], abyte[7]);
      long j = Longs.fromBytes(abyte[8], abyte[9], abyte[10], abyte[11], abyte[12], abyte[13], abyte[14], abyte[15]);
      return new RandomSupport.Seed128bit(i, j);
   }

   public static long m_224599_() {
      return f_189325_.updateAndGet((p_224601_) -> {
         return p_224601_ * 1181783497276652981L;
      }) ^ System.nanoTime();
   }

   public static record Seed128bit(long f_189335_, long f_189336_) {
      public RandomSupport.Seed128bit m_288194_(long p_288963_, long p_288992_) {
         return new RandomSupport.Seed128bit(this.f_189335_ ^ p_288963_, this.f_189336_ ^ p_288992_);
      }

      public RandomSupport.Seed128bit m_288205_(RandomSupport.Seed128bit p_289009_) {
         return this.m_288194_(p_289009_.f_189335_, p_289009_.f_189336_);
      }

      public RandomSupport.Seed128bit m_289608_() {
         return new RandomSupport.Seed128bit(RandomSupport.m_189329_(this.f_189335_), RandomSupport.m_189329_(this.f_189336_));
      }
   }
}