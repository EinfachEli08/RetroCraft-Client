package net.minecraft.world.level.levelgen.structure.templatesystem.rule.blockentity;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import org.slf4j.Logger;

public class AppendLoot implements RuleBlockEntityModifier {
   private static final Logger f_276677_ = LogUtils.getLogger();
   public static final Codec<AppendLoot> f_276688_ = RecordCodecBuilder.create((p_277957_) -> {
      return p_277957_.group(ResourceLocation.f_135803_.fieldOf("loot_table").forGetter((p_277581_) -> {
         return p_277581_.f_276575_;
      })).apply(p_277957_, AppendLoot::new);
   });
   private final ResourceLocation f_276575_;

   public AppendLoot(ResourceLocation p_277694_) {
      this.f_276575_ = p_277694_;
   }

   public CompoundTag m_276854_(RandomSource p_277994_, @Nullable CompoundTag p_277854_) {
      CompoundTag compoundtag = p_277854_ == null ? new CompoundTag() : p_277854_.m_6426_();
      ResourceLocation.f_135803_.encodeStart(NbtOps.f_128958_, this.f_276575_).resultOrPartial(f_276677_::error).ifPresent((p_277353_) -> {
         compoundtag.m_128365_("LootTable", p_277353_);
      });
      compoundtag.m_128356_("LootTableSeed", p_277994_.m_188505_());
      return compoundtag;
   }

   public RuleBlockEntityModifierType<?> m_276855_() {
      return RuleBlockEntityModifierType.f_276561_;
   }
}