package net.minecraft.world.level.levelgen.structure.templatesystem;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;

public class RandomBlockStateMatchTest extends RuleTest {
   public static final Codec<RandomBlockStateMatchTest> f_74275_ = RecordCodecBuilder.create((p_74287_) -> {
      return p_74287_.group(BlockState.f_61039_.fieldOf("block_state").forGetter((p_163770_) -> {
         return p_163770_.f_74276_;
      }), Codec.FLOAT.fieldOf("probability").forGetter((p_163768_) -> {
         return p_163768_.f_74277_;
      })).apply(p_74287_, RandomBlockStateMatchTest::new);
   });
   private final BlockState f_74276_;
   private final float f_74277_;

   public RandomBlockStateMatchTest(BlockState p_74280_, float p_74281_) {
      this.f_74276_ = p_74280_;
      this.f_74277_ = p_74281_;
   }

   public boolean m_213865_(BlockState p_230320_, RandomSource p_230321_) {
      return p_230320_ == this.f_74276_ && p_230321_.m_188501_() < this.f_74277_;
   }

   protected RuleTestType<?> m_7319_() {
      return RuleTestType.f_74317_;
   }
}