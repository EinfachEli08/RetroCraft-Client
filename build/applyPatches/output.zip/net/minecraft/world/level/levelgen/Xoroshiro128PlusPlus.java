package net.minecraft.world.level.levelgen;

import com.mojang.serialization.Codec;
import java.util.stream.LongStream;
import net.minecraft.Util;

public class Xoroshiro128PlusPlus {
   private long f_190089_;
   private long f_190090_;
   public static final Codec<Xoroshiro128PlusPlus> f_286992_ = Codec.LONG_STREAM.comapFlatMap((p_287733_) -> {
      return Util.m_287262_(p_287733_, 2).map((p_287742_) -> {
         return new Xoroshiro128PlusPlus(p_287742_[0], p_287742_[1]);
      });
   }, (p_287687_) -> {
      return LongStream.of(p_287687_.f_190089_, p_287687_.f_190090_);
   });

   public Xoroshiro128PlusPlus(RandomSupport.Seed128bit p_190095_) {
      this(p_190095_.f_189335_(), p_190095_.f_189336_());
   }

   public Xoroshiro128PlusPlus(long p_190092_, long p_190093_) {
      this.f_190089_ = p_190092_;
      this.f_190090_ = p_190093_;
      if ((this.f_190089_ | this.f_190090_) == 0L) {
         this.f_190089_ = -7046029254386353131L;
         this.f_190090_ = 7640891576956012809L;
      }

   }

   public long m_190096_() {
      long i = this.f_190089_;
      long j = this.f_190090_;
      long k = Long.rotateLeft(i + j, 17) + i;
      j ^= i;
      this.f_190089_ = Long.rotateLeft(i, 49) ^ j ^ j << 21;
      this.f_190090_ = Long.rotateLeft(j, 28);
      return k;
   }
}