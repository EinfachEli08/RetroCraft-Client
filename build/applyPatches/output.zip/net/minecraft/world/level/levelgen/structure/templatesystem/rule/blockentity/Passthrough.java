package net.minecraft.world.level.levelgen.structure.templatesystem.rule.blockentity;

import com.mojang.serialization.Codec;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;

public class Passthrough implements RuleBlockEntityModifier {
   public static final Passthrough f_276645_ = new Passthrough();
   public static final Codec<Passthrough> f_276690_ = Codec.unit(f_276645_);

   @Nullable
   public CompoundTag m_276854_(RandomSource p_277737_, @Nullable CompoundTag p_277665_) {
      return p_277665_;
   }

   public RuleBlockEntityModifierType<?> m_276855_() {
      return RuleBlockEntityModifierType.f_276528_;
   }
}