package net.minecraft.world.item;

public interface TooltipFlag {
   TooltipFlag.Default f_256752_ = new TooltipFlag.Default(false, false);
   TooltipFlag.Default f_256730_ = new TooltipFlag.Default(true, false);

   boolean m_7050_();

   boolean m_257552_();

   public static record Default(boolean f_43368_, boolean f_257043_) implements TooltipFlag {
      public boolean m_7050_() {
         return this.f_43368_;
      }

      public boolean m_257552_() {
         return this.f_257043_;
      }

      public TooltipFlag.Default m_257777_() {
         return new TooltipFlag.Default(this.f_43368_, true);
      }
   }
}