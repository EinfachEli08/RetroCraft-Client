package net.minecraft.data.advancements.packs;

import java.util.Comparator;
import java.util.List;
import java.util.Map.Entry;
import java.util.function.Consumer;
import java.util.stream.Stream;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementRewards;
import net.minecraft.advancements.FrameType;
import net.minecraft.advancements.RequirementsStrategy;
import net.minecraft.advancements.critereon.BeeNestDestroyedTrigger;
import net.minecraft.advancements.critereon.BlockPredicate;
import net.minecraft.advancements.critereon.BredAnimalsTrigger;
import net.minecraft.advancements.critereon.ConsumeItemTrigger;
import net.minecraft.advancements.critereon.ContextAwarePredicate;
import net.minecraft.advancements.critereon.EffectsChangedTrigger;
import net.minecraft.advancements.critereon.EnchantmentPredicate;
import net.minecraft.advancements.critereon.EntityFlagsPredicate;
import net.minecraft.advancements.critereon.EntityPredicate;
import net.minecraft.advancements.critereon.EntitySubPredicate;
import net.minecraft.advancements.critereon.FilledBucketTrigger;
import net.minecraft.advancements.critereon.FishingRodHookedTrigger;
import net.minecraft.advancements.critereon.InventoryChangeTrigger;
import net.minecraft.advancements.critereon.ItemPredicate;
import net.minecraft.advancements.critereon.ItemUsedOnLocationTrigger;
import net.minecraft.advancements.critereon.LocationPredicate;
import net.minecraft.advancements.critereon.MinMaxBounds;
import net.minecraft.advancements.critereon.PickedUpItemTrigger;
import net.minecraft.advancements.critereon.PlayerInteractTrigger;
import net.minecraft.advancements.critereon.StartRidingTrigger;
import net.minecraft.advancements.critereon.TameAnimalTrigger;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.advancements.AdvancementSubProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.HoneycombItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Blocks;

public class VanillaHusbandryAdvancements implements AdvancementSubProvider {
   public static final List<EntityType<?>> f_243832_ = List.of(EntityType.f_20457_, EntityType.f_20560_, EntityType.f_20503_, EntityType.f_20520_, EntityType.f_20557_, EntityType.f_20504_, EntityType.f_20510_, EntityType.f_20555_, EntityType.f_20499_, EntityType.f_20505_, EntityType.f_20517_, EntityType.f_20466_, EntityType.f_20553_, EntityType.f_20507_, EntityType.f_20452_, EntityType.f_20550_, EntityType.f_20456_, EntityType.f_20482_, EntityType.f_147035_, EntityType.f_147039_, EntityType.f_243976_);
   public static final List<EntityType<?>> f_244418_ = List.of(EntityType.f_20490_, EntityType.f_217012_, EntityType.f_271264_);
   private static final Item[] f_244058_ = new Item[]{Items.f_42526_, Items.f_42528_, Items.f_42529_, Items.f_42527_};
   private static final Item[] f_244171_ = new Item[]{Items.f_42458_, Items.f_42459_, Items.f_42456_, Items.f_42457_};
   private static final Item[] f_244235_ = new Item[]{Items.f_42410_, Items.f_42400_, Items.f_42406_, Items.f_42485_, Items.f_42486_, Items.f_42436_, Items.f_42437_, Items.f_42526_, Items.f_42527_, Items.f_42528_, Items.f_42529_, Items.f_42530_, Items.f_42531_, Items.f_42572_, Items.f_42575_, Items.f_42579_, Items.f_42580_, Items.f_42581_, Items.f_42582_, Items.f_42583_, Items.f_42591_, Items.f_42619_, Items.f_42620_, Items.f_42674_, Items.f_42675_, Items.f_42677_, Items.f_42687_, Items.f_42697_, Items.f_42698_, Items.f_42699_, Items.f_42658_, Items.f_42659_, Items.f_42730_, Items.f_42732_, Items.f_42734_, Items.f_42576_, Items.f_42718_, Items.f_42780_, Items.f_42787_, Items.f_151079_};
   private static final Item[] f_243834_ = new Item[]{Items.f_42423_, Items.f_42433_, Items.f_42428_, Items.f_42386_, Items.f_42391_, Items.f_42396_};

   public void m_245571_(HolderLookup.Provider p_255680_, Consumer<Advancement> p_251389_) {
      Advancement advancement = Advancement.Builder.m_138353_().m_138371_(Blocks.f_50335_, Component.m_237115_("advancements.husbandry.root.title"), Component.m_237115_("advancements.husbandry.root.description"), new ResourceLocation("textures/gui/advancements/backgrounds/husbandry.png"), FrameType.TASK, false, false, false).m_138386_("consumed_item", ConsumeItemTrigger.TriggerInstance.m_23707_()).m_138389_(p_251389_, "husbandry/root");
      Advancement advancement1 = Advancement.Builder.m_138353_().m_138398_(advancement).m_138371_(Items.f_42405_, Component.m_237115_("advancements.husbandry.plant_seed.title"), Component.m_237115_("advancements.husbandry.plant_seed.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138360_(RequirementsStrategy.f_15979_).m_138386_("wheat", ItemUsedOnLocationTrigger.TriggerInstance.m_286031_(Blocks.f_50092_)).m_138386_("pumpkin_stem", ItemUsedOnLocationTrigger.TriggerInstance.m_286031_(Blocks.f_50189_)).m_138386_("melon_stem", ItemUsedOnLocationTrigger.TriggerInstance.m_286031_(Blocks.f_50190_)).m_138386_("beetroots", ItemUsedOnLocationTrigger.TriggerInstance.m_286031_(Blocks.f_50444_)).m_138386_("nether_wart", ItemUsedOnLocationTrigger.TriggerInstance.m_286031_(Blocks.f_50200_)).m_138386_("torchflower", ItemUsedOnLocationTrigger.TriggerInstance.m_286031_(Blocks.f_271410_)).m_138386_("pitcher_pod", ItemUsedOnLocationTrigger.TriggerInstance.m_286031_(Blocks.f_276665_)).m_138389_(p_251389_, "husbandry/plant_seed");
      Advancement advancement2 = Advancement.Builder.m_138353_().m_138398_(advancement).m_138371_(Items.f_42405_, Component.m_237115_("advancements.husbandry.breed_an_animal.title"), Component.m_237115_("advancements.husbandry.breed_an_animal.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138360_(RequirementsStrategy.f_15979_).m_138386_("bred", BredAnimalsTrigger.TriggerInstance.m_18679_()).m_138389_(p_251389_, "husbandry/breed_an_animal");
      m_266572_(advancement2, p_251389_, f_243832_.stream(), f_244418_.stream());
      m_247039_(Advancement.Builder.m_138353_()).m_138398_(advancement1).m_138371_(Items.f_42410_, Component.m_237115_("advancements.husbandry.balanced_diet.title"), Component.m_237115_("advancements.husbandry.balanced_diet.description"), (ResourceLocation)null, FrameType.CHALLENGE, true, true, false).m_138354_(AdvancementRewards.Builder.m_10005_(100)).m_138389_(p_251389_, "husbandry/balanced_diet");
      Advancement.Builder.m_138353_().m_138398_(advancement1).m_138371_(Items.f_42397_, Component.m_237115_("advancements.husbandry.netherite_hoe.title"), Component.m_237115_("advancements.husbandry.netherite_hoe.description"), (ResourceLocation)null, FrameType.CHALLENGE, true, true, false).m_138354_(AdvancementRewards.Builder.m_10005_(100)).m_138386_("netherite_hoe", InventoryChangeTrigger.TriggerInstance.m_43199_(Items.f_42397_)).m_138389_(p_251389_, "husbandry/obtain_netherite_hoe");
      Advancement advancement3 = Advancement.Builder.m_138353_().m_138398_(advancement).m_138371_(Items.f_42655_, Component.m_237115_("advancements.husbandry.tame_an_animal.title"), Component.m_237115_("advancements.husbandry.tame_an_animal.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138386_("tamed_animal", TameAnimalTrigger.TriggerInstance.m_68854_()).m_138389_(p_251389_, "husbandry/tame_an_animal");
      Advancement advancement4 = m_245640_(Advancement.Builder.m_138353_()).m_138398_(advancement).m_138360_(RequirementsStrategy.f_15979_).m_138371_(Items.f_42523_, Component.m_237115_("advancements.husbandry.fishy_business.title"), Component.m_237115_("advancements.husbandry.fishy_business.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138389_(p_251389_, "husbandry/fishy_business");
      Advancement advancement5 = m_246714_(Advancement.Builder.m_138353_()).m_138398_(advancement4).m_138360_(RequirementsStrategy.f_15979_).m_138371_(Items.f_42456_, Component.m_237115_("advancements.husbandry.tactical_fishing.title"), Component.m_237115_("advancements.husbandry.tactical_fishing.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138389_(p_251389_, "husbandry/tactical_fishing");
      Advancement advancement6 = Advancement.Builder.m_138353_().m_138398_(advancement5).m_138360_(RequirementsStrategy.f_15979_).m_138386_(BuiltInRegistries.f_257033_.m_7981_(Items.f_151057_).m_135815_(), FilledBucketTrigger.TriggerInstance.m_38793_(ItemPredicate.Builder.m_45068_().m_151445_(Items.f_151057_).m_45077_())).m_138371_(Items.f_151057_, Component.m_237115_("advancements.husbandry.axolotl_in_a_bucket.title"), Component.m_237115_("advancements.husbandry.axolotl_in_a_bucket.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138389_(p_251389_, "husbandry/axolotl_in_a_bucket");
      Advancement.Builder.m_138353_().m_138398_(advancement6).m_138386_("kill_axolotl_target", EffectsChangedTrigger.TriggerInstance.m_149277_(EntityPredicate.Builder.m_36633_().m_36636_(EntityType.f_147039_).m_36662_())).m_138371_(Items.f_42459_, Component.m_237115_("advancements.husbandry.kill_axolotl_target.title"), Component.m_237115_("advancements.husbandry.kill_axolotl_target.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138389_(p_251389_, "husbandry/kill_axolotl_target");
      m_247568_(Advancement.Builder.m_138353_()).m_138398_(advancement3).m_138371_(Items.f_42526_, Component.m_237115_("advancements.husbandry.complete_catalogue.title"), Component.m_237115_("advancements.husbandry.complete_catalogue.description"), (ResourceLocation)null, FrameType.CHALLENGE, true, true, false).m_138354_(AdvancementRewards.Builder.m_10005_(50)).m_138389_(p_251389_, "husbandry/complete_catalogue");
      Advancement advancement7 = Advancement.Builder.m_138353_().m_138398_(advancement).m_138386_("safely_harvest_honey", ItemUsedOnLocationTrigger.TriggerInstance.m_285945_(LocationPredicate.Builder.m_52651_().m_52652_(BlockPredicate.Builder.m_17924_().m_204027_(BlockTags.f_13072_).m_17931_()).m_52654_(true), ItemPredicate.Builder.m_45068_().m_151445_(Items.f_42590_))).m_138371_(Items.f_42787_, Component.m_237115_("advancements.husbandry.safely_harvest_honey.title"), Component.m_237115_("advancements.husbandry.safely_harvest_honey.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138389_(p_251389_, "husbandry/safely_harvest_honey");
      Advancement advancement8 = Advancement.Builder.m_138353_().m_138398_(advancement7).m_138371_(Items.f_42784_, Component.m_237115_("advancements.husbandry.wax_on.title"), Component.m_237115_("advancements.husbandry.wax_on.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138386_("wax_on", ItemUsedOnLocationTrigger.TriggerInstance.m_285945_(LocationPredicate.Builder.m_52651_().m_52652_(BlockPredicate.Builder.m_17924_().m_146722_(HoneycombItem.f_150863_.get().keySet()).m_17931_()), ItemPredicate.Builder.m_45068_().m_151445_(Items.f_42784_))).m_138389_(p_251389_, "husbandry/wax_on");
      Advancement.Builder.m_138353_().m_138398_(advancement8).m_138371_(Items.f_42428_, Component.m_237115_("advancements.husbandry.wax_off.title"), Component.m_237115_("advancements.husbandry.wax_off.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138386_("wax_off", ItemUsedOnLocationTrigger.TriggerInstance.m_285945_(LocationPredicate.Builder.m_52651_().m_52652_(BlockPredicate.Builder.m_17924_().m_146722_(HoneycombItem.f_150864_.get().keySet()).m_17931_()), ItemPredicate.Builder.m_45068_().m_151445_(f_243834_))).m_138389_(p_251389_, "husbandry/wax_off");
      Advancement advancement9 = Advancement.Builder.m_138353_().m_138398_(advancement).m_138386_(BuiltInRegistries.f_257033_.m_7981_(Items.f_220210_).m_135815_(), FilledBucketTrigger.TriggerInstance.m_38793_(ItemPredicate.Builder.m_45068_().m_151445_(Items.f_220210_).m_45077_())).m_138371_(Items.f_220210_, Component.m_237115_("advancements.husbandry.tadpole_in_a_bucket.title"), Component.m_237115_("advancements.husbandry.tadpole_in_a_bucket.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138389_(p_251389_, "husbandry/tadpole_in_a_bucket");
      Advancement advancement10 = m_246845_(Advancement.Builder.m_138353_()).m_138398_(advancement9).m_138371_(Items.f_42655_, Component.m_237115_("advancements.husbandry.leash_all_frog_variants.title"), Component.m_237115_("advancements.husbandry.leash_all_frog_variants.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138389_(p_251389_, "husbandry/leash_all_frog_variants");
      Advancement.Builder.m_138353_().m_138398_(advancement10).m_138371_(Items.f_220221_, Component.m_237115_("advancements.husbandry.froglights.title"), Component.m_237115_("advancements.husbandry.froglights.description"), (ResourceLocation)null, FrameType.CHALLENGE, true, true, false).m_138386_("froglights", InventoryChangeTrigger.TriggerInstance.m_43199_(Items.f_220220_, Items.f_220222_, Items.f_220221_)).m_138389_(p_251389_, "husbandry/froglights");
      Advancement.Builder.m_138353_().m_138398_(advancement).m_138386_("silk_touch_nest", BeeNestDestroyedTrigger.TriggerInstance.m_17512_(Blocks.f_50717_, ItemPredicate.Builder.m_45068_().m_45071_(new EnchantmentPredicate(Enchantments.f_44985_, MinMaxBounds.Ints.m_55386_(1))), MinMaxBounds.Ints.m_55371_(3))).m_138371_(Blocks.f_50717_, Component.m_237115_("advancements.husbandry.silk_touch_nest.title"), Component.m_237115_("advancements.husbandry.silk_touch_nest.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138389_(p_251389_, "husbandry/silk_touch_nest");
      Advancement.Builder.m_138353_().m_138398_(advancement).m_138371_(Items.f_42453_, Component.m_237115_("advancements.husbandry.ride_a_boat_with_a_goat.title"), Component.m_237115_("advancements.husbandry.ride_a_boat_with_a_goat.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138386_("ride_a_boat_with_a_goat", StartRidingTrigger.TriggerInstance.m_160401_(EntityPredicate.Builder.m_36633_().m_36644_(EntityPredicate.Builder.m_36633_().m_36636_(EntityType.f_20552_).m_150328_(EntityPredicate.Builder.m_36633_().m_36636_(EntityType.f_147035_).m_36662_()).m_36662_()))).m_138389_(p_251389_, "husbandry/ride_a_boat_with_a_goat");
      Advancement.Builder.m_138353_().m_138398_(advancement).m_138371_(Items.f_151056_, Component.m_237115_("advancements.husbandry.make_a_sign_glow.title"), Component.m_237115_("advancements.husbandry.make_a_sign_glow.description"), (ResourceLocation)null, FrameType.TASK, true, true, false).m_138386_("make_a_sign_glow", ItemUsedOnLocationTrigger.TriggerInstance.m_285945_(LocationPredicate.Builder.m_52651_().m_52652_(BlockPredicate.Builder.m_17924_().m_204027_(BlockTags.f_260523_).m_17931_()), ItemPredicate.Builder.m_45068_().m_151445_(Items.f_151056_))).m_138389_(p_251389_, "husbandry/make_a_sign_glow");
      Advancement advancement11 = Advancement.Builder.m_138353_().m_138398_(advancement).m_138371_(Items.f_42572_, Component.m_237115_("advancements.husbandry.allay_deliver_item_to_player.title"), Component.m_237115_("advancements.husbandry.allay_deliver_item_to_player.description"), (ResourceLocation)null, FrameType.TASK, true, true, true).m_138386_("allay_deliver_item_to_player", PickedUpItemTrigger.TriggerInstance.m_286101_(ContextAwarePredicate.f_285567_, ItemPredicate.f_45028_, EntityPredicate.m_285787_(EntityPredicate.Builder.m_36633_().m_36636_(EntityType.f_217014_).m_36662_()))).m_138389_(p_251389_, "husbandry/allay_deliver_item_to_player");
      Advancement.Builder.m_138353_().m_138398_(advancement11).m_138371_(Items.f_41859_, Component.m_237115_("advancements.husbandry.allay_deliver_cake_to_note_block.title"), Component.m_237115_("advancements.husbandry.allay_deliver_cake_to_note_block.description"), (ResourceLocation)null, FrameType.TASK, true, true, true).m_138386_("allay_deliver_cake_to_note_block", ItemUsedOnLocationTrigger.TriggerInstance.m_285770_(LocationPredicate.Builder.m_52651_().m_52652_(BlockPredicate.Builder.m_17924_().m_146726_(Blocks.f_50065_).m_17931_()), ItemPredicate.Builder.m_45068_().m_151445_(Items.f_42502_))).m_138389_(p_251389_, "husbandry/allay_deliver_cake_to_note_block");
      Advancement advancement12 = Advancement.Builder.m_138353_().m_138398_(advancement).m_138371_(Items.f_276468_, Component.m_237115_("advancements.husbandry.obtain_sniffer_egg.title"), Component.m_237115_("advancements.husbandry.obtain_sniffer_egg.description"), (ResourceLocation)null, FrameType.TASK, true, true, true).m_138386_("obtain_sniffer_egg", InventoryChangeTrigger.TriggerInstance.m_43199_(Items.f_276468_)).m_138389_(p_251389_, "husbandry/obtain_sniffer_egg");
      Advancement advancement13 = Advancement.Builder.m_138353_().m_138398_(advancement12).m_138371_(Items.f_271133_, Component.m_237115_("advancements.husbandry.feed_snifflet.title"), Component.m_237115_("advancements.husbandry.feed_snifflet.description"), (ResourceLocation)null, FrameType.TASK, true, true, true).m_138386_("feed_snifflet", PlayerInteractTrigger.TriggerInstance.m_285812_(ItemPredicate.Builder.m_45068_().m_204145_(ItemTags.f_271449_), EntityPredicate.m_285787_(EntityPredicate.Builder.m_36633_().m_36636_(EntityType.f_271264_).m_36642_(EntityFlagsPredicate.Builder.m_33713_().m_33717_(true).m_33716_()).m_36662_()))).m_138389_(p_251389_, "husbandry/feed_snifflet");
      Advancement.Builder.m_138353_().m_138398_(advancement13).m_138371_(Items.f_276594_, Component.m_237115_("advancements.husbandry.plant_any_sniffer_seed.title"), Component.m_237115_("advancements.husbandry.plant_any_sniffer_seed.description"), (ResourceLocation)null, FrameType.TASK, true, true, true).m_138360_(RequirementsStrategy.f_15979_).m_138386_("torchflower", ItemUsedOnLocationTrigger.TriggerInstance.m_286031_(Blocks.f_271410_)).m_138386_("pitcher_pod", ItemUsedOnLocationTrigger.TriggerInstance.m_286031_(Blocks.f_276665_)).m_138389_(p_251389_, "husbandry/plant_any_sniffer_seed");
   }

   public static Advancement m_266572_(Advancement p_267284_, Consumer<Advancement> p_266923_, Stream<EntityType<?>> p_266961_, Stream<EntityType<?>> p_266751_) {
      return m_266319_(Advancement.Builder.m_138353_(), p_266961_, p_266751_).m_138398_(p_267284_).m_138371_(Items.f_42677_, Component.m_237115_("advancements.husbandry.breed_all_animals.title"), Component.m_237115_("advancements.husbandry.breed_all_animals.description"), (ResourceLocation)null, FrameType.CHALLENGE, true, true, false).m_138354_(AdvancementRewards.Builder.m_10005_(100)).m_138389_(p_266923_, "husbandry/bred_all_animals");
   }

   private static Advancement.Builder m_246845_(Advancement.Builder p_249739_) {
      BuiltInRegistries.f_256770_.m_203611_().forEach((p_286193_) -> {
         p_249739_.m_138386_(p_286193_.m_205785_().m_135782_().toString(), PlayerInteractTrigger.TriggerInstance.m_285812_(ItemPredicate.Builder.m_45068_().m_151445_(Items.f_42655_), EntityPredicate.m_285787_(EntityPredicate.Builder.m_36633_().m_36636_(EntityType.f_217012_).m_218800_(EntitySubPredicate.m_218833_(p_286193_.m_203334_())).m_36662_())));
      });
      return p_249739_;
   }

   private static Advancement.Builder m_247039_(Advancement.Builder p_248532_) {
      for(Item item : f_244235_) {
         p_248532_.m_138386_(BuiltInRegistries.f_257033_.m_7981_(item).m_135815_(), ConsumeItemTrigger.TriggerInstance.m_23703_(item));
      }

      return p_248532_;
   }

   private static Advancement.Builder m_266319_(Advancement.Builder p_266978_, Stream<EntityType<?>> p_267147_, Stream<EntityType<?>> p_267091_) {
      p_267147_.forEach((p_266621_) -> {
         p_266978_.m_138386_(EntityType.m_20613_(p_266621_).toString(), BredAnimalsTrigger.TriggerInstance.m_18667_(EntityPredicate.Builder.m_36633_().m_36636_(p_266621_)));
      });
      p_267091_.forEach((p_266619_) -> {
         p_266978_.m_138386_(EntityType.m_20613_(p_266619_).toString(), BredAnimalsTrigger.TriggerInstance.m_18669_(EntityPredicate.Builder.m_36633_().m_36636_(p_266619_).m_36662_(), EntityPredicate.Builder.m_36633_().m_36636_(p_266619_).m_36662_(), EntityPredicate.f_36550_));
      });
      return p_266978_;
   }

   private static Advancement.Builder m_246714_(Advancement.Builder p_249285_) {
      for(Item item : f_244171_) {
         p_249285_.m_138386_(BuiltInRegistries.f_257033_.m_7981_(item).m_135815_(), FilledBucketTrigger.TriggerInstance.m_38793_(ItemPredicate.Builder.m_45068_().m_151445_(item).m_45077_()));
      }

      return p_249285_;
   }

   private static Advancement.Builder m_245640_(Advancement.Builder p_248725_) {
      for(Item item : f_244058_) {
         p_248725_.m_138386_(BuiltInRegistries.f_257033_.m_7981_(item).m_135815_(), FishingRodHookedTrigger.TriggerInstance.m_40447_(ItemPredicate.f_45028_, EntityPredicate.f_36550_, ItemPredicate.Builder.m_45068_().m_151445_(item).m_45077_()));
      }

      return p_248725_;
   }

   private static Advancement.Builder m_247568_(Advancement.Builder p_249232_) {
      BuiltInRegistries.f_256754_.m_6579_().stream().sorted(Entry.comparingByKey(Comparator.comparing(ResourceKey::m_135782_))).forEach((p_249721_) -> {
         p_249232_.m_138386_(p_249721_.getKey().m_135782_().toString(), TameAnimalTrigger.TriggerInstance.m_68848_(EntityPredicate.Builder.m_36633_().m_218800_(EntitySubPredicate.m_218831_(p_249721_.getValue())).m_36662_()));
      });
      return p_249232_;
   }
}