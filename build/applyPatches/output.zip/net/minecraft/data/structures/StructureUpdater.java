package net.minecraft.data.structures;

import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.util.datafix.DataFixers;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import org.slf4j.Logger;

public class StructureUpdater implements SnbtToNbt.Filter {
   private static final Logger f_126499_ = LogUtils.getLogger();

   public CompoundTag m_6392_(String p_126503_, CompoundTag p_126504_) {
      return p_126503_.startsWith("data/minecraft/structures/") ? m_176822_(p_126503_, p_126504_) : p_126504_;
   }

   public static CompoundTag m_176822_(String p_176823_, CompoundTag p_176824_) {
      StructureTemplate structuretemplate = new StructureTemplate();
      int i = NbtUtils.m_264487_(p_176824_, 500);
      int j = 3437;
      if (i < 3437) {
         f_126499_.warn("SNBT Too old, do not forget to update: {} < {}: {}", i, 3437, p_176823_);
      }

      CompoundTag compoundtag = DataFixTypes.STRUCTURE.m_264218_(DataFixers.m_14512_(), p_176824_, i);
      structuretemplate.m_246595_(BuiltInRegistries.f_256975_.m_255303_(), compoundtag);
      return structuretemplate.m_74618_(new CompoundTag());
   }
}