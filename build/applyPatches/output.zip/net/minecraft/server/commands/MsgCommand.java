package net.minecraft.server.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.tree.LiteralCommandNode;
import java.util.Collection;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.MessageArgument;
import net.minecraft.network.chat.ChatType;
import net.minecraft.network.chat.OutgoingChatMessage;
import net.minecraft.network.chat.PlayerChatMessage;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.PlayerList;

public class MsgCommand {
   public static void m_138060_(CommandDispatcher<CommandSourceStack> p_138061_) {
      LiteralCommandNode<CommandSourceStack> literalcommandnode = p_138061_.register(Commands.m_82127_("msg").then(Commands.m_82129_("targets", EntityArgument.m_91470_()).then(Commands.m_82129_("message", MessageArgument.m_96832_()).executes((p_248155_) -> {
         Collection<ServerPlayer> collection = EntityArgument.m_91477_(p_248155_, "targets");
         if (!collection.isEmpty()) {
            MessageArgument.m_245478_(p_248155_, "message", (p_248154_) -> {
               m_246972_(p_248155_.getSource(), collection, p_248154_);
            });
         }

         return collection.size();
      }))));
      p_138061_.register(Commands.m_82127_("tell").redirect(literalcommandnode));
      p_138061_.register(Commands.m_82127_("w").redirect(literalcommandnode));
   }

   private static void m_246972_(CommandSourceStack p_250209_, Collection<ServerPlayer> p_252344_, PlayerChatMessage p_249416_) {
      ChatType.Bound chattype$bound = ChatType.m_241073_(ChatType.f_240674_, p_250209_);
      OutgoingChatMessage outgoingchatmessage = OutgoingChatMessage.m_247282_(p_249416_);
      boolean flag = false;

      for(ServerPlayer serverplayer : p_252344_) {
         ChatType.Bound chattype$bound1 = ChatType.m_241073_(ChatType.f_240668_, p_250209_).m_241018_(serverplayer.m_5446_());
         p_250209_.m_246719_(outgoingchatmessage, false, chattype$bound1);
         boolean flag1 = p_250209_.m_243061_(serverplayer);
         serverplayer.m_245069_(outgoingchatmessage, flag1, chattype$bound);
         flag |= flag1 && p_249416_.m_243059_();
      }

      if (flag) {
         p_250209_.m_243053_(PlayerList.f_243017_);
      }

   }
}