package net.minecraft.client.gui.font.providers;

import com.mojang.blaze3d.font.GlyphProvider;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import java.io.IOException;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface GlyphProviderDefinition {
   Codec<GlyphProviderDefinition> f_285650_ = GlyphProviderType.f_285607_.dispatch(GlyphProviderDefinition::m_285843_, (p_286256_) -> {
      return p_286256_.m_285822_().codec();
   });

   GlyphProviderType m_285843_();

   Either<GlyphProviderDefinition.Loader, GlyphProviderDefinition.Reference> m_285782_();

   @OnlyIn(Dist.CLIENT)
   public interface Loader {
      GlyphProvider m_285964_(ResourceManager p_286639_) throws IOException;
   }

   @OnlyIn(Dist.CLIENT)
   public static record Reference(ResourceLocation f_285563_) {
   }
}