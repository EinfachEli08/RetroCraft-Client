package net.minecraft.client.gui.screens.worldselection;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.CrashReport;
import net.minecraft.SharedConstants;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.components.toasts.SystemToast;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.navigation.CommonInputs;
import net.minecraft.client.gui.screens.AlertScreen;
import net.minecraft.client.gui.screens.BackupConfirmScreen;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.client.gui.screens.ErrorScreen;
import net.minecraft.client.gui.screens.FaviconTexture;
import net.minecraft.client.gui.screens.GenericDirtMessageScreen;
import net.minecraft.client.gui.screens.LoadingDotsText;
import net.minecraft.client.gui.screens.ProgressScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.SymlinkWarningScreen;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.LevelSettings;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.level.storage.LevelStorageException;
import net.minecraft.world.level.storage.LevelStorageSource;
import net.minecraft.world.level.storage.LevelSummary;
import net.minecraft.world.level.validation.ContentValidationException;
import net.minecraft.world.level.validation.ForbiddenSymlinkInfo;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class WorldSelectionList extends ObjectSelectionList<WorldSelectionList.Entry> {
   static final Logger f_101645_ = LogUtils.getLogger();
   static final DateFormat f_101646_ = new SimpleDateFormat();
   private static final ResourceLocation f_101647_ = new ResourceLocation("textures/misc/unknown_server.png");
   static final ResourceLocation f_101648_ = new ResourceLocation("textures/gui/world_selection.png");
   static final Component f_101649_ = Component.m_237115_("selectWorld.tooltip.fromNewerVersion1").m_130940_(ChatFormatting.RED);
   static final Component f_101650_ = Component.m_237115_("selectWorld.tooltip.fromNewerVersion2").m_130940_(ChatFormatting.RED);
   static final Component f_101651_ = Component.m_237115_("selectWorld.tooltip.snapshot1").m_130940_(ChatFormatting.GOLD);
   static final Component f_101652_ = Component.m_237115_("selectWorld.tooltip.snapshot2").m_130940_(ChatFormatting.GOLD);
   static final Component f_101653_ = Component.m_237115_("selectWorld.locked").m_130940_(ChatFormatting.RED);
   static final Component f_194113_ = Component.m_237115_("selectWorld.conversion.tooltip").m_130940_(ChatFormatting.RED);
   private final SelectWorldScreen f_101654_;
   private CompletableFuture<List<LevelSummary>> f_238666_;
   @Nullable
   private List<LevelSummary> f_238575_;
   private String f_238624_;
   private final WorldSelectionList.LoadingHeader f_233184_;

   public WorldSelectionList(SelectWorldScreen p_239540_, Minecraft p_239541_, int p_239542_, int p_239543_, int p_239544_, int p_239545_, int p_239546_, String p_239547_, @Nullable WorldSelectionList p_239548_) {
      super(p_239541_, p_239542_, p_239543_, p_239544_, p_239545_, p_239546_);
      this.f_101654_ = p_239540_;
      this.f_233184_ = new WorldSelectionList.LoadingHeader(p_239541_);
      this.f_238624_ = p_239547_;
      if (p_239548_ != null) {
         this.f_238666_ = p_239548_.f_238666_;
      } else {
         this.f_238666_ = this.m_233213_();
      }

      this.m_239664_(this.m_239987_());
   }

   protected void m_93516_() {
      this.m_6702_().forEach(WorldSelectionList.Entry::close);
      super.m_93516_();
   }

   @Nullable
   private List<LevelSummary> m_239987_() {
      try {
         return this.f_238666_.getNow((List<LevelSummary>)null);
      } catch (CancellationException | CompletionException completionexception) {
         return null;
      }
   }

   void m_233206_() {
      this.f_238666_ = this.m_233213_();
   }

   public boolean m_7933_(int p_289017_, int p_288966_, int p_289020_) {
      if (CommonInputs.m_278691_(p_289017_)) {
         Optional<WorldSelectionList.WorldListEntry> optional = this.m_101684_();
         if (optional.isPresent()) {
            optional.get().m_101704_();
            return true;
         }
      }

      return super.m_7933_(p_289017_, p_288966_, p_289020_);
   }

   public void m_88315_(GuiGraphics p_283323_, int p_282039_, int p_283339_, float p_281472_) {
      List<LevelSummary> list = this.m_239987_();
      if (list != this.f_238575_) {
         this.m_239664_(list);
      }

      super.m_88315_(p_283323_, p_282039_, p_283339_, p_281472_);
   }

   private void m_239664_(@Nullable List<LevelSummary> p_239665_) {
      if (p_239665_ == null) {
         this.m_233214_();
      } else {
         this.m_233198_(this.f_238624_, p_239665_);
      }

      this.f_238575_ = p_239665_;
   }

   public void m_239900_(String p_239901_) {
      if (this.f_238575_ != null && !p_239901_.equals(this.f_238624_)) {
         this.m_233198_(p_239901_, this.f_238575_);
      }

      this.f_238624_ = p_239901_;
   }

   private CompletableFuture<List<LevelSummary>> m_233213_() {
      LevelStorageSource.LevelCandidates levelstoragesource$levelcandidates;
      try {
         levelstoragesource$levelcandidates = this.f_93386_.m_91392_().m_230833_();
      } catch (LevelStorageException levelstorageexception) {
         f_101645_.error("Couldn't load level list", (Throwable)levelstorageexception);
         this.m_233211_(levelstorageexception.m_230806_());
         return CompletableFuture.completedFuture(List.of());
      }

      if (levelstoragesource$levelcandidates.m_230843_()) {
         CreateWorldScreen.m_232896_(this.f_93386_, (Screen)null);
         return CompletableFuture.completedFuture(List.of());
      } else {
         return this.f_93386_.m_91392_().m_230813_(levelstoragesource$levelcandidates).exceptionally((p_233202_) -> {
            this.f_93386_.m_231412_(CrashReport.m_127521_(p_233202_, "Couldn't load level list"));
            return List.of();
         });
      }
   }

   private void m_233198_(String p_233199_, List<LevelSummary> p_233200_) {
      this.m_93516_();
      p_233199_ = p_233199_.toLowerCase(Locale.ROOT);

      for(LevelSummary levelsummary : p_233200_) {
         if (this.m_233195_(p_233199_, levelsummary)) {
            this.m_7085_(new WorldSelectionList.WorldListEntry(this, levelsummary));
         }
      }

      this.m_233215_();
   }

   private boolean m_233195_(String p_233196_, LevelSummary p_233197_) {
      return p_233197_.m_78361_().toLowerCase(Locale.ROOT).contains(p_233196_) || p_233197_.m_78358_().toLowerCase(Locale.ROOT).contains(p_233196_);
   }

   private void m_233214_() {
      this.m_93516_();
      this.m_7085_(this.f_233184_);
      this.m_233215_();
   }

   private void m_233215_() {
      this.f_101654_.m_169407_(true);
   }

   private void m_233211_(Component p_233212_) {
      this.f_93386_.m_91152_(new ErrorScreen(Component.m_237115_("selectWorld.unable_to_load"), p_233212_));
   }

   protected int m_5756_() {
      return super.m_5756_() + 20;
   }

   public int m_5759_() {
      return super.m_5759_() + 50;
   }

   public void m_6987_(@Nullable WorldSelectionList.Entry p_233190_) {
      super.m_6987_(p_233190_);
      this.f_101654_.m_276090_(p_233190_ != null && p_233190_.m_214209_(), p_233190_ != null);
   }

   public Optional<WorldSelectionList.WorldListEntry> m_101684_() {
      WorldSelectionList.Entry worldselectionlist$entry = this.m_93511_();
      if (worldselectionlist$entry instanceof WorldSelectionList.WorldListEntry worldselectionlist$worldlistentry) {
         return Optional.of(worldselectionlist$worldlistentry);
      } else {
         return Optional.empty();
      }
   }

   public SelectWorldScreen m_101685_() {
      return this.f_101654_;
   }

   public void m_142291_(NarrationElementOutput p_233188_) {
      if (this.m_6702_().contains(this.f_233184_)) {
         this.f_233184_.m_142291_(p_233188_);
      } else {
         super.m_142291_(p_233188_);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public abstract static class Entry extends ObjectSelectionList.Entry<WorldSelectionList.Entry> implements AutoCloseable {
      public abstract boolean m_214209_();

      public void close() {
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class LoadingHeader extends WorldSelectionList.Entry {
      private static final Component f_233218_ = Component.m_237115_("selectWorld.loading_list");
      private final Minecraft f_233219_;

      public LoadingHeader(Minecraft p_233222_) {
         this.f_233219_ = p_233222_;
      }

      public void m_6311_(GuiGraphics p_282319_, int p_283207_, int p_281352_, int p_283332_, int p_282400_, int p_282912_, int p_282760_, int p_281344_, boolean p_283655_, float p_283696_) {
         int i = (this.f_233219_.f_91080_.f_96543_ - this.f_233219_.f_91062_.m_92852_(f_233218_)) / 2;
         int j = p_281352_ + (p_282912_ - 9) / 2;
         p_282319_.m_280614_(this.f_233219_.f_91062_, f_233218_, i, j, 16777215, false);
         String s = LoadingDotsText.m_232744_(Util.m_137550_());
         int k = (this.f_233219_.f_91080_.f_96543_ - this.f_233219_.f_91062_.m_92895_(s)) / 2;
         int l = j + 9;
         p_282319_.m_280056_(this.f_233219_.f_91062_, s, k, l, 8421504, false);
      }

      public Component m_142172_() {
         return f_233218_;
      }

      public boolean m_214209_() {
         return false;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public final class WorldListEntry extends WorldSelectionList.Entry implements AutoCloseable {
      private static final int f_170312_ = 32;
      private static final int f_170313_ = 32;
      private static final int f_170314_ = 0;
      private static final int f_170315_ = 32;
      private static final int f_170316_ = 64;
      private static final int f_170317_ = 96;
      private static final int f_170318_ = 0;
      private static final int f_170319_ = 32;
      private final Minecraft f_101693_;
      private final SelectWorldScreen f_101694_;
      private final LevelSummary f_101695_;
      private final FaviconTexture f_101698_;
      @Nullable
      private Path f_101697_;
      private long f_101699_;

      public WorldListEntry(WorldSelectionList p_101702_, LevelSummary p_101703_) {
         this.f_101693_ = p_101702_.f_93386_;
         this.f_101694_ = p_101702_.m_101685_();
         this.f_101695_ = p_101703_;
         this.f_101698_ = FaviconTexture.m_289210_(this.f_101693_.m_91097_(), p_101703_.m_78358_());
         this.f_101697_ = p_101703_.m_230875_();
         this.m_289856_();
         this.m_101746_();
      }

      private void m_289856_() {
         if (this.f_101697_ != null) {
            try {
               BasicFileAttributes basicfileattributes = Files.readAttributes(this.f_101697_, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
               if (basicfileattributes.isSymbolicLink()) {
                  List<ForbiddenSymlinkInfo> list = new ArrayList<>();
                  this.f_101693_.m_91392_().m_289863_().m_289900_(this.f_101697_, list);
                  if (!list.isEmpty()) {
                     WorldSelectionList.f_101645_.warn(ContentValidationException.m_289907_(this.f_101697_, list));
                     this.f_101697_ = null;
                  } else {
                     basicfileattributes = Files.readAttributes(this.f_101697_, BasicFileAttributes.class);
                  }
               }

               if (!basicfileattributes.isRegularFile()) {
                  this.f_101697_ = null;
               }
            } catch (NoSuchFileException nosuchfileexception) {
               this.f_101697_ = null;
            } catch (IOException ioexception) {
               WorldSelectionList.f_101645_.error("could not validate symlink", (Throwable)ioexception);
               this.f_101697_ = null;
            }

         }
      }

      public Component m_142172_() {
         Component component = Component.m_237110_("narrator.select.world_info", this.f_101695_.m_78361_(), new Date(this.f_101695_.m_78366_()), this.f_101695_.m_78376_());
         Component component1;
         if (this.f_101695_.m_78375_()) {
            component1 = CommonComponents.m_267603_(component, WorldSelectionList.f_101653_);
         } else {
            component1 = component;
         }

         return Component.m_237110_("narrator.select", component1);
      }

      public void m_6311_(GuiGraphics p_281612_, int p_281353_, int p_283181_, int p_282820_, int p_282420_, int p_281855_, int p_283204_, int p_283025_, boolean p_283396_, float p_282938_) {
         String s = this.f_101695_.m_78361_();
         String s1 = this.f_101695_.m_78358_();
         long i = this.f_101695_.m_78366_();
         if (i != -1L) {
            s1 = s1 + " (" + WorldSelectionList.f_101646_.format(new Date(i)) + ")";
         }

         if (StringUtils.isEmpty(s)) {
            s = I18n.m_118938_("selectWorld.world") + " " + (p_281353_ + 1);
         }

         Component component = this.f_101695_.m_78376_();
         p_281612_.m_280056_(this.f_101693_.f_91062_, s, p_282820_ + 32 + 3, p_283181_ + 1, 16777215, false);
         p_281612_.m_280056_(this.f_101693_.f_91062_, s1, p_282820_ + 32 + 3, p_283181_ + 9 + 3, 8421504, false);
         p_281612_.m_280614_(this.f_101693_.f_91062_, component, p_282820_ + 32 + 3, p_283181_ + 9 + 9 + 3, 8421504, false);
         RenderSystem.enableBlend();
         p_281612_.m_280163_(this.f_101698_.m_289196_(), p_282820_, p_283181_, 0.0F, 0.0F, 32, 32, 32, 32);
         RenderSystem.disableBlend();
         if (this.f_101693_.f_91066_.m_231828_().m_231551_() || p_283396_) {
            p_281612_.m_280509_(p_282820_, p_283181_, p_282820_ + 32, p_283181_ + 32, -1601138544);
            int j = p_283204_ - p_282820_;
            boolean flag = j < 32;
            int k = flag ? 32 : 0;
            if (this.f_101695_ instanceof LevelSummary.SymlinkLevelSummary) {
               p_281612_.m_280163_(WorldSelectionList.f_101648_, p_282820_, p_283181_, 96.0F, (float)k, 32, 32, 256, 256);
               p_281612_.m_280163_(WorldSelectionList.f_101648_, p_282820_, p_283181_, 32.0F, (float)k, 32, 32, 256, 256);
               return;
            }

            if (this.f_101695_.m_78375_()) {
               p_281612_.m_280163_(WorldSelectionList.f_101648_, p_282820_, p_283181_, 96.0F, (float)k, 32, 32, 256, 256);
               if (flag) {
                  this.f_101694_.m_257959_(this.f_101693_.f_91062_.m_92923_(WorldSelectionList.f_101653_, 175));
               }
            } else if (this.f_101695_.m_193020_()) {
               p_281612_.m_280163_(WorldSelectionList.f_101648_, p_282820_, p_283181_, 96.0F, (float)k, 32, 32, 256, 256);
               if (flag) {
                  this.f_101694_.m_257959_(this.f_101693_.f_91062_.m_92923_(WorldSelectionList.f_194113_, 175));
               }
            } else if (this.f_101695_.m_78372_()) {
               p_281612_.m_280163_(WorldSelectionList.f_101648_, p_282820_, p_283181_, 32.0F, (float)k, 32, 32, 256, 256);
               if (this.f_101695_.m_78373_()) {
                  p_281612_.m_280163_(WorldSelectionList.f_101648_, p_282820_, p_283181_, 96.0F, (float)k, 32, 32, 256, 256);
                  if (flag) {
                     this.f_101694_.m_257959_(ImmutableList.of(WorldSelectionList.f_101649_.m_7532_(), WorldSelectionList.f_101650_.m_7532_()));
                  }
               } else if (!SharedConstants.m_183709_().m_132498_()) {
                  p_281612_.m_280163_(WorldSelectionList.f_101648_, p_282820_, p_283181_, 64.0F, (float)k, 32, 32, 256, 256);
                  if (flag) {
                     this.f_101694_.m_257959_(ImmutableList.of(WorldSelectionList.f_101651_.m_7532_(), WorldSelectionList.f_101652_.m_7532_()));
                  }
               }
            } else {
               p_281612_.m_280163_(WorldSelectionList.f_101648_, p_282820_, p_283181_, 0.0F, (float)k, 32, 32, 256, 256);
            }
         }

      }

      public boolean m_6375_(double p_101706_, double p_101707_, int p_101708_) {
         if (this.f_101695_.m_164916_()) {
            return true;
         } else {
            WorldSelectionList.this.m_6987_((WorldSelectionList.Entry)this);
            if (p_101706_ - (double)WorldSelectionList.this.m_5747_() <= 32.0D) {
               this.m_101704_();
               return true;
            } else if (Util.m_137550_() - this.f_101699_ < 250L) {
               this.m_101704_();
               return true;
            } else {
               this.f_101699_ = Util.m_137550_();
               return true;
            }
         }
      }

      public void m_101704_() {
         if (!this.f_101695_.m_164916_()) {
            if (this.f_101695_ instanceof LevelSummary.SymlinkLevelSummary) {
               this.f_101693_.m_91152_(new SymlinkWarningScreen(this.f_101694_));
            } else {
               LevelSummary.BackupStatus levelsummary$backupstatus = this.f_101695_.m_164914_();
               if (levelsummary$backupstatus.m_164931_()) {
                  String s = "selectWorld.backupQuestion." + levelsummary$backupstatus.m_164933_();
                  String s1 = "selectWorld.backupWarning." + levelsummary$backupstatus.m_164933_();
                  MutableComponent mutablecomponent = Component.m_237115_(s);
                  if (levelsummary$backupstatus.m_164932_()) {
                     mutablecomponent.m_130944_(ChatFormatting.BOLD, ChatFormatting.RED);
                  }

                  Component component = Component.m_237110_(s1, this.f_101695_.m_78370_(), SharedConstants.m_183709_().m_132493_());
                  this.f_101693_.m_91152_(new BackupConfirmScreen(this.f_101694_, (p_289912_, p_289913_) -> {
                     if (p_289912_) {
                        String s2 = this.f_101695_.m_78358_();

                        try (LevelStorageSource.LevelStorageAccess levelstoragesource$levelstorageaccess = this.f_101693_.m_91392_().m_289864_(s2)) {
                           EditWorldScreen.m_101258_(levelstoragesource$levelstorageaccess);
                        } catch (IOException ioexception) {
                           SystemToast.m_94852_(this.f_101693_, s2);
                           WorldSelectionList.f_101645_.error("Failed to backup level {}", s2, ioexception);
                        } catch (ContentValidationException contentvalidationexception) {
                           WorldSelectionList.f_101645_.warn("{}", (Object)contentvalidationexception.getMessage());
                           this.f_101693_.m_91152_(new SymlinkWarningScreen(this.f_101694_));
                        }
                     }

                     this.m_101744_();
                  }, mutablecomponent, component, false));
               } else if (this.f_101695_.m_78373_()) {
                  this.f_101693_.m_91152_(new ConfirmScreen((p_101741_) -> {
                     if (p_101741_) {
                        try {
                           this.m_101744_();
                        } catch (Exception exception) {
                           WorldSelectionList.f_101645_.error("Failure to open 'future world'", (Throwable)exception);
                           this.f_101693_.m_91152_(new AlertScreen(() -> {
                              this.f_101693_.m_91152_(this.f_101694_);
                           }, Component.m_237115_("selectWorld.futureworld.error.title"), Component.m_237115_("selectWorld.futureworld.error.text")));
                        }
                     } else {
                        this.f_101693_.m_91152_(this.f_101694_);
                     }

                  }, Component.m_237115_("selectWorld.versionQuestion"), Component.m_237110_("selectWorld.versionWarning", this.f_101695_.m_78370_()), Component.m_237115_("selectWorld.versionJoinButton"), CommonComponents.f_130656_));
               } else {
                  this.m_101744_();
               }

            }
         }
      }

      public void m_101738_() {
         this.f_101693_.m_91152_(new ConfirmScreen((p_170322_) -> {
            if (p_170322_) {
               this.f_101693_.m_91152_(new ProgressScreen(true));
               this.m_170323_();
            }

            this.f_101693_.m_91152_(this.f_101694_);
         }, Component.m_237115_("selectWorld.deleteQuestion"), Component.m_237110_("selectWorld.deleteWarning", this.f_101695_.m_78361_()), Component.m_237115_("selectWorld.deleteButton"), CommonComponents.f_130656_));
      }

      public void m_170323_() {
         LevelStorageSource levelstoragesource = this.f_101693_.m_91392_();
         String s = this.f_101695_.m_78358_();

         try (LevelStorageSource.LevelStorageAccess levelstoragesource$levelstorageaccess = levelstoragesource.m_78260_(s)) {
            levelstoragesource$levelstorageaccess.m_78311_();
         } catch (IOException ioexception) {
            SystemToast.m_94866_(this.f_101693_, s);
            WorldSelectionList.f_101645_.error("Failed to delete world {}", s, ioexception);
         }

         WorldSelectionList.this.m_233206_();
      }

      public void m_101739_() {
         if (this.f_101695_ instanceof LevelSummary.SymlinkLevelSummary) {
            this.f_101693_.m_91152_(new SymlinkWarningScreen(this.f_101694_));
         } else {
            this.m_101745_();
            String s = this.f_101695_.m_78358_();

            try {
               LevelStorageSource.LevelStorageAccess levelstoragesource$levelstorageaccess = this.f_101693_.m_91392_().m_289864_(s);
               this.f_101693_.m_91152_(new EditWorldScreen((p_233244_) -> {
                  try {
                     levelstoragesource$levelstorageaccess.close();
                  } catch (IOException ioexception1) {
                     WorldSelectionList.f_101645_.error("Failed to unlock level {}", s, ioexception1);
                  }

                  if (p_233244_) {
                     WorldSelectionList.this.m_233206_();
                  }

                  this.f_101693_.m_91152_(this.f_101694_);
               }, levelstoragesource$levelstorageaccess));
            } catch (IOException ioexception) {
               SystemToast.m_94852_(this.f_101693_, s);
               WorldSelectionList.f_101645_.error("Failed to access level {}", s, ioexception);
               WorldSelectionList.this.m_233206_();
            } catch (ContentValidationException contentvalidationexception) {
               WorldSelectionList.f_101645_.warn("{}", (Object)contentvalidationexception.getMessage());
               this.f_101693_.m_91152_(new SymlinkWarningScreen(this.f_101694_));
            }

         }
      }

      public void m_101743_() {
         if (this.f_101695_ instanceof LevelSummary.SymlinkLevelSummary) {
            this.f_101693_.m_91152_(new SymlinkWarningScreen(this.f_101694_));
         } else {
            this.m_101745_();

            try (LevelStorageSource.LevelStorageAccess levelstoragesource$levelstorageaccess = this.f_101693_.m_91392_().m_289864_(this.f_101695_.m_78358_())) {
               Pair<LevelSettings, WorldCreationContext> pair = this.f_101693_.m_231466_().m_246225_(levelstoragesource$levelstorageaccess);
               LevelSettings levelsettings = pair.getFirst();
               WorldCreationContext worldcreationcontext = pair.getSecond();
               Path path = CreateWorldScreen.m_100906_(levelstoragesource$levelstorageaccess.m_78283_(LevelResource.f_78180_), this.f_101693_);
               if (worldcreationcontext.f_244272_().m_247070_()) {
                  this.f_101693_.m_91152_(new ConfirmScreen((p_275882_) -> {
                     this.f_101693_.m_91152_((Screen)(p_275882_ ? CreateWorldScreen.m_275847_(this.f_101693_, this.f_101694_, levelsettings, worldcreationcontext, path) : this.f_101694_));
                  }, Component.m_237115_("selectWorld.recreate.customized.title"), Component.m_237115_("selectWorld.recreate.customized.text"), CommonComponents.f_130659_, CommonComponents.f_130656_));
               } else {
                  this.f_101693_.m_91152_(CreateWorldScreen.m_275847_(this.f_101693_, this.f_101694_, levelsettings, worldcreationcontext, path));
               }
            } catch (ContentValidationException contentvalidationexception) {
               WorldSelectionList.f_101645_.warn("{}", (Object)contentvalidationexception.getMessage());
               this.f_101693_.m_91152_(new SymlinkWarningScreen(this.f_101694_));
            } catch (Exception exception) {
               WorldSelectionList.f_101645_.error("Unable to recreate world", (Throwable)exception);
               this.f_101693_.m_91152_(new AlertScreen(() -> {
                  this.f_101693_.m_91152_(this.f_101694_);
               }, Component.m_237115_("selectWorld.recreate.error.title"), Component.m_237115_("selectWorld.recreate.error.text")));
            }

         }
      }

      private void m_101744_() {
         this.f_101693_.m_91106_().m_120367_(SimpleSoundInstance.m_263171_(SoundEvents.f_12490_, 1.0F));
         if (this.f_101693_.m_91392_().m_78255_(this.f_101695_.m_78358_())) {
            this.m_101745_();
            this.f_101693_.m_231466_().m_233133_(this.f_101694_, this.f_101695_.m_78358_());
         }

      }

      private void m_101745_() {
         this.f_101693_.m_91346_(new GenericDirtMessageScreen(Component.m_237115_("selectWorld.data_read")));
      }

      private void m_101746_() {
         boolean flag = this.f_101697_ != null && Files.isRegularFile(this.f_101697_);
         if (flag) {
            try (InputStream inputstream = Files.newInputStream(this.f_101697_)) {
               this.f_101698_.m_289201_(NativeImage.m_85058_(inputstream));
            } catch (Throwable throwable) {
               WorldSelectionList.f_101645_.error("Invalid icon for world {}", this.f_101695_.m_78358_(), throwable);
               this.f_101697_ = null;
            }
         } else {
            this.f_101698_.m_289218_();
         }

      }

      public void close() {
         this.f_101698_.close();
      }

      public String m_170324_() {
         return this.f_101695_.m_78361_();
      }

      public boolean m_214209_() {
         return !this.f_101695_.m_164916_();
      }
   }
}