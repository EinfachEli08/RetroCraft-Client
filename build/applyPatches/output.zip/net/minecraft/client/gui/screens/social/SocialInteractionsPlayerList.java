package net.minecraft.client.gui.screens.social;

import com.google.common.base.Strings;
import com.google.common.base.Suppliers;
import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.multiplayer.chat.ChatLog;
import net.minecraft.client.multiplayer.chat.LoggedChatEvent;
import net.minecraft.client.multiplayer.chat.LoggedChatMessage;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class SocialInteractionsPlayerList extends ContainerObjectSelectionList<PlayerEntry> {
   private final SocialInteractionsScreen f_100692_;
   private final List<PlayerEntry> f_100694_ = Lists.newArrayList();
   @Nullable
   private String f_100695_;

   public SocialInteractionsPlayerList(SocialInteractionsScreen p_100697_, Minecraft p_100698_, int p_100699_, int p_100700_, int p_100701_, int p_100702_, int p_100703_) {
      super(p_100698_, p_100699_, p_100700_, p_100701_, p_100702_, p_100703_);
      this.f_100692_ = p_100697_;
      this.m_93488_(false);
      this.m_93496_(false);
   }

   protected void m_280310_(GuiGraphics p_281892_) {
      p_281892_.m_280588_(this.f_93393_, this.f_93390_ + 4, this.f_93392_, this.f_93391_);
   }

   public void m_240702_(Collection<UUID> p_240798_, double p_240792_, boolean p_240829_) {
      Map<UUID, PlayerEntry> map = new HashMap<>();
      this.m_240718_(p_240798_, map);
      this.m_240708_(map, p_240829_);
      this.m_240705_(map.values(), p_240792_);
   }

   private void m_240718_(Collection<UUID> p_240813_, Map<UUID, PlayerEntry> p_240796_) {
      ClientPacketListener clientpacketlistener = this.f_93386_.f_91074_.f_108617_;

      for(UUID uuid : p_240813_) {
         PlayerInfo playerinfo = clientpacketlistener.m_104949_(uuid);
         if (playerinfo != null) {
            boolean flag = playerinfo.m_247101_();
            p_240796_.put(uuid, new PlayerEntry(this.f_93386_, this.f_100692_, uuid, playerinfo.m_105312_().getName(), playerinfo::m_105337_, flag));
         }
      }

   }

   private void m_240708_(Map<UUID, PlayerEntry> p_240780_, boolean p_240827_) {
      for(GameProfile gameprofile : m_246121_(this.f_93386_.m_239211_().m_239899_())) {
         PlayerEntry playerentry;
         if (p_240827_) {
            playerentry = p_240780_.computeIfAbsent(gameprofile.getId(), (p_243147_) -> {
               PlayerEntry playerentry1 = new PlayerEntry(this.f_93386_, this.f_100692_, gameprofile.getId(), gameprofile.getName(), Suppliers.memoize(() -> {
                  return this.f_93386_.m_91109_().m_240306_(gameprofile);
               }), true);
               playerentry1.m_100619_(true);
               return playerentry1;
            });
         } else {
            playerentry = p_240780_.get(gameprofile.getId());
            if (playerentry == null) {
               continue;
            }
         }

         playerentry.m_240730_(true);
      }

   }

   private static Collection<GameProfile> m_246121_(ChatLog p_250748_) {
      Set<GameProfile> set = new ObjectLinkedOpenHashSet<>();

      for(int i = p_250748_.m_245950_(); i >= p_250748_.m_246004_(); --i) {
         LoggedChatEvent loggedchatevent = p_250748_.m_239049_(i);
         if (loggedchatevent instanceof LoggedChatMessage.Player loggedchatmessage$player) {
            if (loggedchatmessage$player.f_241690_().m_245272_()) {
               set.add(loggedchatmessage$player.f_241668_());
            }
         }
      }

      return set;
   }

   private void m_240704_() {
      this.f_100694_.sort(Comparator.<PlayerEntry, Integer>comparing((p_240744_) -> {
         if (p_240744_.m_100618_().equals(this.f_93386_.m_91094_().m_240411_())) {
            return 0;
         } else if (p_240744_.m_100618_().version() == 2) {
            return 4;
         } else if (this.f_93386_.m_239211_().m_253247_(p_240744_.m_100618_())) {
            return 1;
         } else {
            return p_240744_.m_240694_() ? 2 : 3;
         }
      }).thenComparing((p_240745_) -> {
         if (!p_240745_.m_100600_().isBlank()) {
            int i = p_240745_.m_100600_().codePointAt(0);
            if (i == 95 || i >= 97 && i <= 122 || i >= 65 && i <= 90 || i >= 48 && i <= 57) {
               return 0;
            }
         }

         return 1;
      }).thenComparing(PlayerEntry::m_100600_, String::compareToIgnoreCase));
   }

   private void m_240705_(Collection<PlayerEntry> p_240809_, double p_240830_) {
      this.f_100694_.clear();
      this.f_100694_.addAll(p_240809_);
      this.m_240704_();
      this.m_100725_();
      this.m_5988_(this.f_100694_);
      this.m_93410_(p_240830_);
   }

   private void m_100725_() {
      if (this.f_100695_ != null) {
         this.f_100694_.removeIf((p_100710_) -> {
            return !p_100710_.m_100600_().toLowerCase(Locale.ROOT).contains(this.f_100695_);
         });
         this.m_5988_(this.f_100694_);
      }

   }

   public void m_100717_(String p_100718_) {
      this.f_100695_ = p_100718_;
   }

   public boolean m_100724_() {
      return this.f_100694_.isEmpty();
   }

   public void m_100714_(PlayerInfo p_100715_, SocialInteractionsScreen.Page p_100716_) {
      UUID uuid = p_100715_.m_105312_().getId();

      for(PlayerEntry playerentry : this.f_100694_) {
         if (playerentry.m_100618_().equals(uuid)) {
            playerentry.m_100619_(false);
            return;
         }
      }

      if ((p_100716_ == SocialInteractionsScreen.Page.ALL || this.f_93386_.m_91266_().m_100684_(uuid)) && (Strings.isNullOrEmpty(this.f_100695_) || p_100715_.m_105312_().getName().toLowerCase(Locale.ROOT).contains(this.f_100695_))) {
         boolean flag = p_100715_.m_247101_();
         PlayerEntry playerentry1 = new PlayerEntry(this.f_93386_, this.f_100692_, p_100715_.m_105312_().getId(), p_100715_.m_105312_().getName(), p_100715_::m_105337_, flag);
         this.m_7085_(playerentry1);
         this.f_100694_.add(playerentry1);
      }

   }

   public void m_100722_(UUID p_100723_) {
      for(PlayerEntry playerentry : this.f_100694_) {
         if (playerentry.m_100618_().equals(p_100723_)) {
            playerentry.m_100619_(true);
            return;
         }
      }

   }
}