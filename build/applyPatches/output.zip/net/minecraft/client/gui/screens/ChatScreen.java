package net.minecraft.client.gui.screens;

import javax.annotation.Nullable;
import net.minecraft.client.GuiMessageTag;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.gui.components.CommandSuggestions;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.util.Mth;
import net.minecraft.util.StringUtil;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.commons.lang3.StringUtils;

@OnlyIn(Dist.CLIENT)
public class ChatScreen extends Screen {
   public static final double f_169234_ = 7.0D;
   private static final Component f_169235_ = Component.m_237115_("chat_screen.usage");
   private static final int f_240354_ = 210;
   private String f_95574_ = "";
   private int f_95575_ = -1;
   protected EditBox f_95573_;
   private String f_95576_;
   CommandSuggestions f_95577_;

   public ChatScreen(String p_95579_) {
      super(Component.m_237115_("chat_screen.title"));
      this.f_95576_ = p_95579_;
   }

   protected void m_7856_() {
      this.f_95575_ = this.f_96541_.f_91065_.m_93076_().m_93797_().size();
      this.f_95573_ = new EditBox(this.f_96541_.f_243022_, 4, this.f_96544_ - 12, this.f_96543_ - 4, 12, Component.m_237115_("chat.editBox")) {
         protected MutableComponent m_5646_() {
            return super.m_5646_().m_7220_(ChatScreen.this.f_95577_.m_272218_());
         }
      };
      this.f_95573_.m_94199_(256);
      this.f_95573_.m_94182_(false);
      this.f_95573_.m_94144_(this.f_95576_);
      this.f_95573_.m_94151_(this::m_95610_);
      this.f_95573_.m_94190_(false);
      this.m_7787_(this.f_95573_);
      this.f_95577_ = new CommandSuggestions(this.f_96541_, this, this.f_95573_, this.f_96547_, false, false, 1, 10, true, -805306368);
      this.f_95577_.m_93881_();
      this.m_264313_(this.f_95573_);
   }

   public void m_6574_(Minecraft p_95600_, int p_95601_, int p_95602_) {
      String s = this.f_95573_.m_94155_();
      this.m_6575_(p_95600_, p_95601_, p_95602_);
      this.m_95612_(s);
      this.f_95577_.m_93881_();
   }

   public void m_7861_() {
      this.f_96541_.f_91065_.m_93076_().m_93810_();
   }

   public void m_86600_() {
      this.f_95573_.m_94120_();
   }

   private void m_95610_(String p_95611_) {
      String s = this.f_95573_.m_94155_();
      this.f_95577_.m_93922_(!s.equals(this.f_95576_));
      this.f_95577_.m_93881_();
   }

   public boolean m_7933_(int p_95591_, int p_95592_, int p_95593_) {
      if (this.f_95577_.m_93888_(p_95591_, p_95592_, p_95593_)) {
         return true;
      } else if (super.m_7933_(p_95591_, p_95592_, p_95593_)) {
         return true;
      } else if (p_95591_ == 256) {
         this.f_96541_.m_91152_((Screen)null);
         return true;
      } else if (p_95591_ != 257 && p_95591_ != 335) {
         if (p_95591_ == 265) {
            this.m_95588_(-1);
            return true;
         } else if (p_95591_ == 264) {
            this.m_95588_(1);
            return true;
         } else if (p_95591_ == 266) {
            this.f_96541_.f_91065_.m_93076_().m_205360_(this.f_96541_.f_91065_.m_93076_().m_93816_() - 1);
            return true;
         } else if (p_95591_ == 267) {
            this.f_96541_.f_91065_.m_93076_().m_205360_(-this.f_96541_.f_91065_.m_93076_().m_93816_() + 1);
            return true;
         } else {
            return false;
         }
      } else {
         if (this.m_241797_(this.f_95573_.m_94155_(), true)) {
            this.f_96541_.m_91152_((Screen)null);
         }

         return true;
      }
   }

   public boolean m_6050_(double p_95581_, double p_95582_, double p_95583_) {
      p_95583_ = Mth.m_14008_(p_95583_, -1.0D, 1.0D);
      if (this.f_95577_.m_93882_(p_95583_)) {
         return true;
      } else {
         if (!m_96638_()) {
            p_95583_ *= 7.0D;
         }

         this.f_96541_.f_91065_.m_93076_().m_205360_((int)p_95583_);
         return true;
      }
   }

   public boolean m_6375_(double p_95585_, double p_95586_, int p_95587_) {
      if (this.f_95577_.m_93884_((double)((int)p_95585_), (double)((int)p_95586_), p_95587_)) {
         return true;
      } else {
         if (p_95587_ == 0) {
            ChatComponent chatcomponent = this.f_96541_.f_91065_.m_93076_();
            if (chatcomponent.m_93772_(p_95585_, p_95586_)) {
               return true;
            }

            Style style = this.m_232701_(p_95585_, p_95586_);
            if (style != null && this.m_5561_(style)) {
               this.f_95576_ = this.f_95573_.m_94155_();
               return true;
            }
         }

         return this.f_95573_.m_6375_(p_95585_, p_95586_, p_95587_) ? true : super.m_6375_(p_95585_, p_95586_, p_95587_);
      }
   }

   protected void m_6697_(String p_95606_, boolean p_95607_) {
      if (p_95607_) {
         this.f_95573_.m_94144_(p_95606_);
      } else {
         this.f_95573_.m_94164_(p_95606_);
      }

   }

   public void m_95588_(int p_95589_) {
      int i = this.f_95575_ + p_95589_;
      int j = this.f_96541_.f_91065_.m_93076_().m_93797_().size();
      i = Mth.m_14045_(i, 0, j);
      if (i != this.f_95575_) {
         if (i == j) {
            this.f_95575_ = j;
            this.f_95573_.m_94144_(this.f_95574_);
         } else {
            if (this.f_95575_ == j) {
               this.f_95574_ = this.f_95573_.m_94155_();
            }

            this.f_95573_.m_94144_(this.f_96541_.f_91065_.m_93076_().m_93797_().get(i));
            this.f_95577_.m_93922_(false);
            this.f_95575_ = i;
         }
      }
   }

   public void m_88315_(GuiGraphics p_282470_, int p_282674_, int p_282014_, float p_283132_) {
      p_282470_.m_280509_(2, this.f_96544_ - 14, this.f_96543_ - 2, this.f_96544_ - 2, this.f_96541_.f_91066_.m_92143_(Integer.MIN_VALUE));
      this.f_95573_.m_88315_(p_282470_, p_282674_, p_282014_, p_283132_);
      super.m_88315_(p_282470_, p_282674_, p_282014_, p_283132_);
      this.f_95577_.m_280540_(p_282470_, p_282674_, p_282014_);
      GuiMessageTag guimessagetag = this.f_96541_.f_91065_.m_93076_().m_240463_((double)p_282674_, (double)p_282014_);
      if (guimessagetag != null && guimessagetag.f_240381_() != null) {
         p_282470_.m_280245_(this.f_96547_, this.f_96547_.m_92923_(guimessagetag.f_240381_(), 210), p_282674_, p_282014_);
      } else {
         Style style = this.m_232701_((double)p_282674_, (double)p_282014_);
         if (style != null && style.m_131186_() != null) {
            p_282470_.m_280304_(this.f_96547_, style, p_282674_, p_282014_);
         }
      }

   }

   public boolean m_7043_() {
      return false;
   }

   private void m_95612_(String p_95613_) {
      this.f_95573_.m_94144_(p_95613_);
   }

   protected void m_142228_(NarrationElementOutput p_169238_) {
      p_169238_.m_169146_(NarratedElementType.TITLE, this.m_96636_());
      p_169238_.m_169146_(NarratedElementType.USAGE, f_169235_);
      String s = this.f_95573_.m_94155_();
      if (!s.isEmpty()) {
         p_169238_.m_142047_().m_169146_(NarratedElementType.TITLE, Component.m_237110_("chat_screen.message", s));
      }

   }

   @Nullable
   private Style m_232701_(double p_232702_, double p_232703_) {
      return this.f_96541_.f_91065_.m_93076_().m_93800_(p_232702_, p_232703_);
   }

   public boolean m_241797_(String p_242400_, boolean p_242161_) {
      p_242400_ = this.m_232706_(p_242400_);
      if (p_242400_.isEmpty()) {
         return true;
      } else {
         if (p_242161_) {
            this.f_96541_.f_91065_.m_93076_().m_93783_(p_242400_);
         }

         if (p_242400_.startsWith("/")) {
            this.f_96541_.f_91074_.f_108617_.m_246623_(p_242400_.substring(1));
         } else {
            this.f_96541_.f_91074_.f_108617_.m_246175_(p_242400_);
         }

         return true;
      }
   }

   public String m_232706_(String p_232707_) {
      return StringUtil.m_216469_(StringUtils.normalizeSpace(p_232707_.trim()));
   }
}