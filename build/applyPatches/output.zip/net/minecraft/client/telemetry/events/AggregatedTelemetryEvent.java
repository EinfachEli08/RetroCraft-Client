package net.minecraft.client.telemetry.events;

import java.time.Duration;
import java.time.Instant;
import javax.annotation.Nullable;
import net.minecraft.client.telemetry.TelemetryEventSender;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class AggregatedTelemetryEvent {
   private static final int f_260549_ = 60000;
   private static final int f_260454_ = 10;
   private int f_260572_;
   private boolean f_260520_ = false;
   @Nullable
   private Instant f_260699_;

   public void m_260947_() {
      this.f_260520_ = true;
      this.f_260699_ = Instant.now();
      this.f_260572_ = 0;
   }

   public void m_263206_(TelemetryEventSender p_263410_) {
      if (this.m_261168_()) {
         this.m_260835_();
         ++this.f_260572_;
         this.f_260699_ = Instant.now();
      }

      if (this.m_261228_()) {
         this.m_260819_(p_263410_);
         this.f_260572_ = 0;
      }

   }

   public boolean m_261168_() {
      return this.f_260520_ && this.f_260699_ != null && Duration.between(this.f_260699_, Instant.now()).toMillis() > 60000L;
   }

   public boolean m_261228_() {
      return this.f_260572_ >= 10;
   }

   public void m_261217_() {
      this.f_260520_ = false;
   }

   protected int m_261091_() {
      return this.f_260572_;
   }

   public abstract void m_260835_();

   public abstract void m_260819_(TelemetryEventSender p_263328_);
}