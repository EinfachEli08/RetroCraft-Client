package net.minecraft.client.multiplayer.chat;

import com.mojang.authlib.GameProfile;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.PlayerChatMessage;
import net.minecraft.util.ExtraCodecs;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface LoggedChatMessage extends LoggedChatEvent {
   static LoggedChatMessage.Player m_261049_(GameProfile p_261832_, PlayerChatMessage p_261491_, ChatTrustLevel p_262141_) {
      return new LoggedChatMessage.Player(p_261832_, p_261491_, p_262141_);
   }

   static LoggedChatMessage.System m_241821_(Component p_242325_, Instant p_242334_) {
      return new LoggedChatMessage.System(p_242325_, p_242334_);
   }

   Component m_241831_();

   default Component m_241813_() {
      return this.m_241831_();
   }

   boolean m_241866_(UUID p_242315_);

   @OnlyIn(Dist.CLIENT)
   public static record Player(GameProfile f_241668_, PlayerChatMessage f_241690_, ChatTrustLevel f_241609_) implements LoggedChatMessage {
      public static final Codec<LoggedChatMessage.Player> f_252425_ = RecordCodecBuilder.create((p_261382_) -> {
         return p_261382_.group(ExtraCodecs.f_252453_.fieldOf("profile").forGetter(LoggedChatMessage.Player::f_241668_), PlayerChatMessage.f_252410_.forGetter(LoggedChatMessage.Player::f_241690_), ChatTrustLevel.f_252530_.optionalFieldOf("trust_level", ChatTrustLevel.SECURE).forGetter(LoggedChatMessage.Player::f_241609_)).apply(p_261382_, LoggedChatMessage.Player::new);
      });
      private static final DateTimeFormatter f_241693_ = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT);

      public Component m_241831_() {
         if (!this.f_241690_.f_242992_().m_243095_()) {
            Component component = this.f_241690_.f_242992_().m_246134_(this.f_241690_.m_245728_());
            return (Component)(component != null ? component : Component.m_237119_());
         } else {
            return this.f_241690_.m_245692_();
         }
      }

      public Component m_241813_() {
         Component component = this.m_241831_();
         Component component1 = this.m_241827_();
         return Component.m_237110_("gui.chatSelection.message.narrate", this.f_241668_.getName(), component, component1);
      }

      public Component m_241865_() {
         Component component = this.m_241827_();
         return Component.m_237110_("gui.chatSelection.heading", this.f_241668_.getName(), component);
      }

      private Component m_241827_() {
         LocalDateTime localdatetime = LocalDateTime.ofInstant(this.f_241690_.m_241109_(), ZoneOffset.systemDefault());
         return Component.m_237113_(localdatetime.format(f_241693_)).m_130944_(ChatFormatting.ITALIC, ChatFormatting.GRAY);
      }

      public boolean m_241866_(UUID p_242210_) {
         return this.f_241690_.m_243088_(p_242210_);
      }

      public UUID m_241803_() {
         return this.f_241668_.getId();
      }

      public LoggedChatEvent.Type m_252883_() {
         return LoggedChatEvent.Type.PLAYER;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static record System(Component f_241673_, Instant f_241622_) implements LoggedChatMessage {
      public static final Codec<LoggedChatMessage.System> f_252498_ = RecordCodecBuilder.create((p_253996_) -> {
         return p_253996_.group(ExtraCodecs.f_252442_.fieldOf("message").forGetter(LoggedChatMessage.System::f_241673_), ExtraCodecs.f_216159_.fieldOf("time_stamp").forGetter(LoggedChatMessage.System::f_241622_)).apply(p_253996_, LoggedChatMessage.System::new);
      });

      public Component m_241831_() {
         return this.f_241673_;
      }

      public boolean m_241866_(UUID p_242173_) {
         return false;
      }

      public LoggedChatEvent.Type m_252883_() {
         return LoggedChatEvent.Type.SYSTEM;
      }
   }
}