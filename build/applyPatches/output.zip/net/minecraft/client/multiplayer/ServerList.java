package net.minecraft.client.multiplayer;

import com.google.common.collect.Lists;
import com.mojang.logging.LogUtils;
import java.io.File;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.util.thread.ProcessorMailbox;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class ServerList {
   private static final Logger f_105425_ = LogUtils.getLogger();
   private static final ProcessorMailbox<Runnable> f_233836_ = ProcessorMailbox.m_18751_(Util.m_183991_(), "server-list-io");
   private static final int f_233837_ = 16;
   private final Minecraft f_105426_;
   private final List<ServerData> f_105427_ = Lists.newArrayList();
   private final List<ServerData> f_233838_ = Lists.newArrayList();

   public ServerList(Minecraft p_105430_) {
      this.f_105426_ = p_105430_;
   }

   public void m_105431_() {
      try {
         this.f_105427_.clear();
         this.f_233838_.clear();
         CompoundTag compoundtag = NbtIo.m_128953_(new File(this.f_105426_.f_91069_, "servers.dat"));
         if (compoundtag == null) {
            return;
         }

         ListTag listtag = compoundtag.m_128437_("servers", 10);

         for(int i = 0; i < listtag.size(); ++i) {
            CompoundTag compoundtag1 = listtag.m_128728_(i);
            ServerData serverdata = ServerData.m_105385_(compoundtag1);
            if (compoundtag1.m_128471_("hidden")) {
               this.f_233838_.add(serverdata);
            } else {
               this.f_105427_.add(serverdata);
            }
         }
      } catch (Exception exception) {
         f_105425_.error("Couldn't load server list", (Throwable)exception);
      }

   }

   public void m_105442_() {
      try {
         ListTag listtag = new ListTag();

         for(ServerData serverdata : this.f_105427_) {
            CompoundTag compoundtag = serverdata.m_105378_();
            compoundtag.m_128379_("hidden", false);
            listtag.add(compoundtag);
         }

         for(ServerData serverdata1 : this.f_233838_) {
            CompoundTag compoundtag2 = serverdata1.m_105378_();
            compoundtag2.m_128379_("hidden", true);
            listtag.add(compoundtag2);
         }

         CompoundTag compoundtag1 = new CompoundTag();
         compoundtag1.m_128365_("servers", listtag);
         File file2 = File.createTempFile("servers", ".dat", this.f_105426_.f_91069_);
         NbtIo.m_128955_(compoundtag1, file2);
         File file3 = new File(this.f_105426_.f_91069_, "servers.dat_old");
         File file1 = new File(this.f_105426_.f_91069_, "servers.dat");
         Util.m_137462_(file1, file2, file3);
      } catch (Exception exception) {
         f_105425_.error("Couldn't save server list", (Throwable)exception);
      }

   }

   public ServerData m_105432_(int p_105433_) {
      return this.f_105427_.get(p_105433_);
   }

   @Nullable
   public ServerData m_233845_(String p_233846_) {
      for(ServerData serverdata : this.f_105427_) {
         if (serverdata.f_105363_.equals(p_233846_)) {
            return serverdata;
         }
      }

      for(ServerData serverdata1 : this.f_233838_) {
         if (serverdata1.f_105363_.equals(p_233846_)) {
            return serverdata1;
         }
      }

      return null;
   }

   @Nullable
   public ServerData m_233847_(String p_233848_) {
      for(int i = 0; i < this.f_233838_.size(); ++i) {
         ServerData serverdata = this.f_233838_.get(i);
         if (serverdata.f_105363_.equals(p_233848_)) {
            this.f_233838_.remove(i);
            this.f_105427_.add(serverdata);
            return serverdata;
         }
      }

      return null;
   }

   public void m_105440_(ServerData p_105441_) {
      if (!this.f_105427_.remove(p_105441_)) {
         this.f_233838_.remove(p_105441_);
      }

   }

   public void m_233842_(ServerData p_233843_, boolean p_233844_) {
      if (p_233844_) {
         this.f_233838_.add(0, p_233843_);

         while(this.f_233838_.size() > 16) {
            this.f_233838_.remove(this.f_233838_.size() - 1);
         }
      } else {
         this.f_105427_.add(p_233843_);
      }

   }

   public int m_105445_() {
      return this.f_105427_.size();
   }

   public void m_105434_(int p_105435_, int p_105436_) {
      ServerData serverdata = this.m_105432_(p_105435_);
      this.f_105427_.set(p_105435_, this.m_105432_(p_105436_));
      this.f_105427_.set(p_105436_, serverdata);
      this.m_105442_();
   }

   public void m_105437_(int p_105438_, ServerData p_105439_) {
      this.f_105427_.set(p_105438_, p_105439_);
   }

   private static boolean m_233839_(ServerData p_233840_, List<ServerData> p_233841_) {
      for(int i = 0; i < p_233841_.size(); ++i) {
         ServerData serverdata = p_233841_.get(i);
         if (serverdata.f_105362_.equals(p_233840_.f_105362_) && serverdata.f_105363_.equals(p_233840_.f_105363_)) {
            p_233841_.set(i, p_233840_);
            return true;
         }
      }

      return false;
   }

   public static void m_105446_(ServerData p_105447_) {
      f_233836_.m_6937_(() -> {
         ServerList serverlist = new ServerList(Minecraft.m_91087_());
         serverlist.m_105431_();
         if (!m_233839_(p_105447_, serverlist.f_105427_)) {
            m_233839_(p_105447_, serverlist.f_233838_);
         }

         serverlist.m_105442_();
      });
   }
}