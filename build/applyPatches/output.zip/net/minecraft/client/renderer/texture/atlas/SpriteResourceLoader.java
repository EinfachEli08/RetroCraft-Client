package net.minecraft.client.renderer.texture.atlas;

import com.google.common.collect.ImmutableList;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Dynamic;
import com.mojang.serialization.JsonOps;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.client.renderer.texture.MissingTextureAtlasSprite;
import net.minecraft.client.renderer.texture.SpriteContents;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class SpriteResourceLoader {
   private static final Logger f_260482_ = LogUtils.getLogger();
   private static final FileToIdConverter f_260445_ = new FileToIdConverter("atlases", ".json");
   private final List<SpriteSource> f_260697_;

   private SpriteResourceLoader(List<SpriteSource> p_261613_) {
      this.f_260697_ = p_261613_;
   }

   public List<Supplier<SpriteContents>> m_260886_(ResourceManager p_261989_) {
      final Map<ResourceLocation, SpriteSource.SpriteSupplier> map = new HashMap<>();
      SpriteSource.Output spritesource$output = new SpriteSource.Output() {
         public void m_260840_(ResourceLocation p_262067_, SpriteSource.SpriteSupplier p_261936_) {
            SpriteSource.SpriteSupplier spritesource$spritesupplier = map.put(p_262067_, p_261936_);
            if (spritesource$spritesupplier != null) {
               spritesource$spritesupplier.m_260986_();
            }

         }

         public void m_260801_(Predicate<ResourceLocation> p_261939_) {
            Iterator<Map.Entry<ResourceLocation, SpriteSource.SpriteSupplier>> iterator = map.entrySet().iterator();

            while(iterator.hasNext()) {
               Map.Entry<ResourceLocation, SpriteSource.SpriteSupplier> entry = iterator.next();
               if (p_261939_.test(entry.getKey())) {
                  entry.getValue().m_260986_();
                  iterator.remove();
               }
            }

         }
      };
      this.f_260697_.forEach((p_261747_) -> {
         p_261747_.m_260891_(p_261989_, spritesource$output);
      });
      ImmutableList.Builder<Supplier<SpriteContents>> builder = ImmutableList.builder();
      builder.add(MissingTextureAtlasSprite::m_246104_);
      builder.addAll(map.values());
      return builder.build();
   }

   public static SpriteResourceLoader m_261166_(ResourceManager p_261551_, ResourceLocation p_261709_) {
      ResourceLocation resourcelocation = f_260445_.m_245698_(p_261709_);
      List<SpriteSource> list = new ArrayList<>();

      for(Resource resource : p_261551_.m_213829_(resourcelocation)) {
         try (BufferedReader bufferedreader = resource.m_215508_()) {
            Dynamic<JsonElement> dynamic = new Dynamic<>(JsonOps.INSTANCE, JsonParser.parseReader(bufferedreader));
            list.addAll(SpriteSources.f_260551_.parse(dynamic).getOrThrow(false, f_260482_::error));
         } catch (Exception exception) {
            f_260482_.warn("Failed to parse atlas definition {} in pack {}", resourcelocation, resource.m_215506_(), exception);
         }
      }

      return new SpriteResourceLoader(list);
   }
}