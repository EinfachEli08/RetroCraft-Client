package net.minecraft.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.mojang.math.Transformation;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.Display;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

@OnlyIn(Dist.CLIENT)
public abstract class DisplayRenderer<T extends Display, S> extends EntityRenderer<T> {
   private final EntityRenderDispatcher f_268749_;

   protected DisplayRenderer(EntityRendererProvider.Context p_270168_) {
      super(p_270168_);
      this.f_268749_ = p_270168_.m_174022_();
   }

   public ResourceLocation m_5478_(T p_270675_) {
      return TextureAtlas.f_118259_;
   }

   public void m_7392_(T p_270405_, float p_270225_, float p_270279_, PoseStack p_270728_, MultiBufferSource p_270209_, int p_270298_) {
      Display.RenderState display$renderstate = p_270405_.m_276844_();
      if (display$renderstate != null) {
         S s = this.m_269580_(p_270405_);
         if (s != null) {
            float f = p_270405_.m_272147_(p_270279_);
            this.f_114477_ = display$renderstate.f_276607_().m_269229_(f);
            this.f_114478_ = display$renderstate.f_276693_().m_269229_(f);
            int i = display$renderstate.f_276438_();
            int j = i != -1 ? i : p_270298_;
            super.m_7392_(p_270405_, p_270225_, p_270279_, p_270728_, p_270209_, j);
            p_270728_.m_85836_();
            p_270728_.m_252781_(this.m_269592_(display$renderstate, p_270405_));
            Transformation transformation = display$renderstate.f_276585_().m_269136_(f);
            p_270728_.m_252931_(transformation.m_252783_());
            p_270728_.m_85850_().m_252943_().rotate(transformation.m_253244_()).rotate(transformation.m_252848_());
            this.m_276924_(p_270405_, s, p_270728_, p_270209_, j, f);
            p_270728_.m_85849_();
         }
      }
   }

   private Quaternionf m_269592_(Display.RenderState p_277846_, T p_271013_) {
      Camera camera = this.f_268749_.f_114358_;
      Quaternionf quaternionf;
      switch (p_277846_.f_276506_()) {
         case FIXED:
            quaternionf = p_271013_.m_269190_();
            break;
         case HORIZONTAL:
            quaternionf = (new Quaternionf()).rotationYXZ(-0.017453292F * p_271013_.m_146908_(), -0.017453292F * camera.m_90589_(), 0.0F);
            break;
         case VERTICAL:
            quaternionf = (new Quaternionf()).rotationYXZ((float)Math.PI - ((float)Math.PI / 180F) * camera.m_90590_(), ((float)Math.PI / 180F) * p_271013_.m_146909_(), 0.0F);
            break;
         case CENTER:
            quaternionf = (new Quaternionf()).rotationYXZ((float)Math.PI - ((float)Math.PI / 180F) * camera.m_90590_(), -0.017453292F * camera.m_90589_(), 0.0F);
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      return quaternionf;
   }

   @Nullable
   protected abstract S m_269580_(T p_270246_);

   protected abstract void m_276924_(T p_277862_, S p_277363_, PoseStack p_277686_, MultiBufferSource p_277429_, int p_278023_, float p_277453_);

   @OnlyIn(Dist.CLIENT)
   public static class BlockDisplayRenderer extends DisplayRenderer<Display.BlockDisplay, Display.BlockDisplay.BlockRenderState> {
      private final BlockRenderDispatcher f_268487_;

      protected BlockDisplayRenderer(EntityRendererProvider.Context p_270283_) {
         super(p_270283_);
         this.f_268487_ = p_270283_.m_234597_();
      }

      @Nullable
      protected Display.BlockDisplay.BlockRenderState m_269580_(Display.BlockDisplay p_277721_) {
         return p_277721_.m_276881_();
      }

      public void m_276924_(Display.BlockDisplay p_277939_, Display.BlockDisplay.BlockRenderState p_277885_, PoseStack p_277831_, MultiBufferSource p_277554_, int p_278071_, float p_277847_) {
         this.f_268487_.m_110912_(p_277885_.f_276526_(), p_277831_, p_277554_, p_278071_, OverlayTexture.f_118083_);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class ItemDisplayRenderer extends DisplayRenderer<Display.ItemDisplay, Display.ItemDisplay.ItemRenderState> {
      private final ItemRenderer f_268604_;

      protected ItemDisplayRenderer(EntityRendererProvider.Context p_270110_) {
         super(p_270110_);
         this.f_268604_ = p_270110_.m_174025_();
      }

      @Nullable
      protected Display.ItemDisplay.ItemRenderState m_269580_(Display.ItemDisplay p_277464_) {
         return p_277464_.m_277122_();
      }

      public void m_276924_(Display.ItemDisplay p_277863_, Display.ItemDisplay.ItemRenderState p_277481_, PoseStack p_277889_, MultiBufferSource p_277509_, int p_277861_, float p_277670_) {
         p_277889_.m_252781_(Axis.f_252436_.m_252961_((float)Math.PI));
         this.f_268604_.m_269128_(p_277481_.f_276600_(), p_277481_.f_276629_(), p_277861_, OverlayTexture.f_118083_, p_277889_, p_277509_, p_277863_.m_9236_(), p_277863_.m_19879_());
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class TextDisplayRenderer extends DisplayRenderer<Display.TextDisplay, Display.TextDisplay.TextRenderState> {
      private final Font f_268575_;

      protected TextDisplayRenderer(EntityRendererProvider.Context p_271012_) {
         super(p_271012_);
         this.f_268575_ = p_271012_.m_174028_();
      }

      private Display.TextDisplay.CachedInfo m_269268_(Component p_270823_, int p_270893_) {
         List<FormattedCharSequence> list = this.f_268575_.m_92923_(p_270823_, p_270893_);
         List<Display.TextDisplay.CachedLine> list1 = new ArrayList<>(list.size());
         int i = 0;

         for(FormattedCharSequence formattedcharsequence : list) {
            int j = this.f_268575_.m_92724_(formattedcharsequence);
            i = Math.max(i, j);
            list1.add(new Display.TextDisplay.CachedLine(formattedcharsequence, j));
         }

         return new Display.TextDisplay.CachedInfo(list1, i);
      }

      @Nullable
      protected Display.TextDisplay.TextRenderState m_269580_(Display.TextDisplay p_277947_) {
         return p_277947_.m_277174_();
      }

      public void m_276924_(Display.TextDisplay p_277522_, Display.TextDisplay.TextRenderState p_277620_, PoseStack p_277536_, MultiBufferSource p_277845_, int p_278046_, float p_277769_) {
         byte b0 = p_277620_.f_276556_();
         boolean flag = (b0 & 2) != 0;
         boolean flag1 = (b0 & 4) != 0;
         boolean flag2 = (b0 & 1) != 0;
         Display.TextDisplay.Align display$textdisplay$align = Display.TextDisplay.m_269384_(b0);
         byte b1 = (byte)p_277620_.f_276579_().m_269120_(p_277769_);
         int i;
         if (flag1) {
            float f = Minecraft.m_91087_().f_91066_.m_92141_(0.25F);
            i = (int)(f * 255.0F) << 24;
         } else {
            i = p_277620_.f_276562_().m_269120_(p_277769_);
         }

         float f2 = 0.0F;
         Matrix4f matrix4f = p_277536_.m_85850_().m_252922_();
         matrix4f.rotate((float)Math.PI, 0.0F, 1.0F, 0.0F);
         matrix4f.scale(-0.025F, -0.025F, -0.025F);
         Display.TextDisplay.CachedInfo display$textdisplay$cachedinfo = p_277522_.m_269343_(this::m_269268_);
         int j = 9 + 1;
         int k = display$textdisplay$cachedinfo.f_268557_();
         int l = display$textdisplay$cachedinfo.f_268675_().size() * j;
         matrix4f.translate(1.0F - (float)k / 2.0F, (float)(-l), 0.0F);
         if (i != 0) {
            VertexConsumer vertexconsumer = p_277845_.m_6299_(flag ? RenderType.m_269508_() : RenderType.m_269058_());
            vertexconsumer.m_252986_(matrix4f, -1.0F, -1.0F, 0.0F).m_193479_(i).m_85969_(p_278046_).m_5752_();
            vertexconsumer.m_252986_(matrix4f, -1.0F, (float)l, 0.0F).m_193479_(i).m_85969_(p_278046_).m_5752_();
            vertexconsumer.m_252986_(matrix4f, (float)k, (float)l, 0.0F).m_193479_(i).m_85969_(p_278046_).m_5752_();
            vertexconsumer.m_252986_(matrix4f, (float)k, -1.0F, 0.0F).m_193479_(i).m_85969_(p_278046_).m_5752_();
         }

         for(Display.TextDisplay.CachedLine display$textdisplay$cachedline : display$textdisplay$cachedinfo.f_268675_()) {
            float f3;
            switch (display$textdisplay$align) {
               case LEFT:
                  f3 = 0.0F;
                  break;
               case RIGHT:
                  f3 = (float)(k - display$textdisplay$cachedline.f_268443_());
                  break;
               case CENTER:
                  f3 = (float)k / 2.0F - (float)display$textdisplay$cachedline.f_268443_() / 2.0F;
                  break;
               default:
                  throw new IncompatibleClassChangeError();
            }

            float f1 = f3;
            this.f_268575_.m_272191_(display$textdisplay$cachedline.f_268516_(), f1, f2, b1 << 24 | 16777215, flag2, matrix4f, p_277845_, flag ? Font.DisplayMode.SEE_THROUGH : Font.DisplayMode.POLYGON_OFFSET, 0, p_278046_);
            f2 += (float)j;
         }

      }
   }
}