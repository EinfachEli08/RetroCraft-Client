package com.mojang.blaze3d.platform;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;
import org.joml.Vector3f;

@OnlyIn(Dist.CLIENT)
public class Lighting {
   private static final Vector3f f_84919_ = (new Vector3f(0.2F, 1.0F, -0.7F)).normalize();
   private static final Vector3f f_84920_ = (new Vector3f(-0.2F, 1.0F, 0.7F)).normalize();
   private static final Vector3f f_84921_ = (new Vector3f(0.2F, 1.0F, -0.7F)).normalize();
   private static final Vector3f f_84922_ = (new Vector3f(-0.2F, -1.0F, 0.7F)).normalize();
   private static final Vector3f f_166381_ = (new Vector3f(0.2F, -1.0F, -1.0F)).normalize();
   private static final Vector3f f_166382_ = (new Vector3f(-0.2F, -1.0F, 0.0F)).normalize();

   public static void m_252995_(Matrix4f p_254421_) {
      RenderSystem.setupLevelDiffuseLighting(f_84921_, f_84922_, p_254421_);
   }

   public static void m_252756_(Matrix4f p_254246_) {
      RenderSystem.setupLevelDiffuseLighting(f_84919_, f_84920_, p_254246_);
   }

   public static void m_84930_() {
      RenderSystem.setupGuiFlatDiffuseLighting(f_84919_, f_84920_);
   }

   public static void m_84931_() {
      RenderSystem.setupGui3DDiffuseLighting(f_84919_, f_84920_);
   }

   public static void m_166384_() {
      RenderSystem.setShaderLights(f_166381_, f_166382_);
   }
}